../lib/a-utf8-x64-debug/up_src_binary32_log2_log2f.c.o: \
 ../src/binary32/log2/log2f.c
