../lib/a-utf8-x86-debug/up_src_binary64_acosh_acosh.c.o: \
 ../src/binary64/acosh/acosh.c
