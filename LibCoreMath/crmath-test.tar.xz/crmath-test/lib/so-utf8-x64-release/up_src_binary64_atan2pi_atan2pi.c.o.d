../lib/so-utf8-x64-release/up_src_binary64_atan2pi_atan2pi.c.o: \
 ../src/binary64/atan2pi/atan2pi.c ../src/binary64/atan2pi/tint.h
../src/binary64/atan2pi/tint.h:
