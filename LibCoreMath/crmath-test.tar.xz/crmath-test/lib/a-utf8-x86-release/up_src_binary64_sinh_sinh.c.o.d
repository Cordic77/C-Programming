../lib/a-utf8-x86-release/up_src_binary64_sinh_sinh.c.o: \
 ../src/binary64/sinh/sinh.c
