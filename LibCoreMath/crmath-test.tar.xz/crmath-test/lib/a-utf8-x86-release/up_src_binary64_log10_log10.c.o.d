../lib/a-utf8-x86-release/up_src_binary64_log10_log10.c.o: \
 ../src/binary64/log10/log10.c ../src/binary64/log10/dint.h
../src/binary64/log10/dint.h:
