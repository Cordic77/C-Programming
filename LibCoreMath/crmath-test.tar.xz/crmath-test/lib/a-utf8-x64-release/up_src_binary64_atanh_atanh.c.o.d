../lib/a-utf8-x64-release/up_src_binary64_atanh_atanh.c.o: \
 ../src/binary64/atanh/atanh.c
