#pragma once
#ifndef SC_COUNTOF_H_
#define SC_COUNTOF_H_

#include "2028/stdcountof.h"

#endif /* SC_COUNTOF_H_ */
