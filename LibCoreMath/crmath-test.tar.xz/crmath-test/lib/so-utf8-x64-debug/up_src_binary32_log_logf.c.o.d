../lib/so-utf8-x64-debug/up_src_binary32_log_logf.c.o: \
 ../src/binary32/log/logf.c
