../lib/so-utf8-x64-release/up_src_binary64_sinpi_sinpi.c.o: \
 ../src/binary64/sinpi/sinpi.c
