../lib/so-utf8-x64-release/up_src_binary32_atanh_atanhf.c.o: \
 ../src/binary32/atanh/atanhf.c
