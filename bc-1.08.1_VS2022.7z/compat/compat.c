#include <stdio.h>                /* perror() */
#include <stdlib.h>               /* exit() */

#define WIN32_LEAN_AND_MEAN       /* Exclude APIs such as Cryptography, DDE, RPC, Shell, and Windows Sockets */
#define NOSERVICE                 /* Additional NOservice definitions: NOMCX, NOIME, NOSOUND, NOCOMM, NOKANJI, NORPC, ... */
#define _WINSOCKAPI_              /* Prevent windows.h from including winsock.h */
#define _WIN32_DCOM               /* Include all DCOM (Distributed Component Object Model) centric definitions */
#include <windows.h>              /* ... pull in Windows headers! */

#define RtlGenRandom SystemFunction036
EXTERN_C BOOLEAN NTAPI RtlGenRandom(PVOID RandomBuffer, ULONG RandomBufferLength);
/*#pragma comment(lib, "advapi32.lib")*/

extern long int random (void)
{ unsigned char
    buf [sizeof(long int)];

  /* CryptGenRandom is a cryptographically secure pseudorandom number
     generator function that is included in Microsoft CryptoAPI: */
  if (not RtlGenRandom (buf, (ULONG)sizeof(buf)))
  {
		perror("bc: RtlGenRandom() failed");
		exit(EXIT_FAILURE);
  }

  return (*(long int *)buf);
}
