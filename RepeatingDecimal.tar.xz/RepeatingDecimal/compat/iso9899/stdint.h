#pragma once
#ifndef SC_STDINT_H_
#define SC_STDINT_H_

#include "1999/stdint.h"

#endif /* SC_STDINT_H_ */
