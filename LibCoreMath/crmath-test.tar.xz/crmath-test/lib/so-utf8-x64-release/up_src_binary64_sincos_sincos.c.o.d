../lib/so-utf8-x64-release/up_src_binary64_sincos_sincos.c.o: \
 ../src/binary64/sincos/sincos.c
