../lib/a-utf8-x86-release/up_src_binary32_atan_atanf.c.o: \
 ../src/binary32/atan/atanf.c
