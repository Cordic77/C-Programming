#pragma once
#ifndef SC_STDBOOL_H_
#define SC_STDBOOL_H_

#include "1999/stdbool.h"

#endif /* SC_STDBOOL_H_ */
