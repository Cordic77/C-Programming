../lib/a-utf8-x86-release/up_src_binary64_asin_asin.c.o: \
 ../src/binary64/asin/asin.c
