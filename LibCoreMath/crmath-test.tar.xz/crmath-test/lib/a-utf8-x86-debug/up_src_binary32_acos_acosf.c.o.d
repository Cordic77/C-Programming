../lib/a-utf8-x86-debug/up_src_binary32_acos_acosf.c.o: \
 ../src/binary32/acos/acosf.c
