../lib/so-utf8-x64-debug/up_src_binary32_lgamma_lgammaf.c.o: \
 ../src/binary32/lgamma/lgammaf.c
