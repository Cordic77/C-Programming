../lib/a-utf8-x86-release/up_src_binary32_atan2_atan2f.c.o: \
 ../src/binary32/atan2/atan2f.c
