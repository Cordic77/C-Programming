#include <stdio.h>
#include <stdlib.h>               /* EXIT_SUCCESS, EXIT_FAILURE */
#include <string.h>               /* strerror() */
#include <errno.h>                /* extern int errno; */
#include <math.h>                 /* HUGE_VAL */
#include <float.h>                /* DBL_MIN, DBL_MAX */

/* If "gmp.h" is included, then "decimal2fraction.c" provides a GNU GMP aware
   solution that will work with arbitrary large double values; otherwise, one
   only suitable for small double values – fitting into an int64_t – will be
   loaded by including "decimal2fraction-u64-poc.c":
*/
#include <gmp.h>                  /* GNU Multiple Precision Arithmetic Library */

#include "stdint.h"               /* (u)int64_t */

#include "stdcountof.h"

/*#include <gmp.h>*/
#if defined(__GMP_H__)
#define HAS_GNU_GMP 1
#else
#define HAS_GNU_GMP 0
#endif

#if HAS_GNU_GMP
extern int decimal_to_fraction (double const double_val, mpz_t numerator, mpz_t denominator);
#else /* decimal_to_fraction (double, unsigned long long): */
extern int decimal_to_fraction (double const double_val, int64_t *numerator, uint64_t *denominator);
#endif


int main (int argc, char *argv [])
{
  #if HAS_GNU_GMP
  double test_values [] = {-DBL_MIN, DBL_MAX, -2.75, 12.125, 0.007653333333333333};

  mpz_t numerator, denominator;
  mpz_inits (numerator, denominator, NULL);

  #define ref
  #else
  double test_values [] = {-2.75, 12.125, 0.007653333333333333};

  int64_t numerator;
  uint64_t denominator;

  #define ref &
  #endif
  { size_t i = 0;

    /* Prefer any user-passed values over the above test cases: */
    if (argc > 1)
    { char const *double_str = argv [1];
      double double_val;
      char *endptr;

      errno = 0;
      double_val = strtod (double_str, &endptr);

      if ((endptr == double_str)  /* nothing parsed from the string? */
       || (errno == ERANGE && (double_val == HUGE_VAL || double_val == -HUGE_VAL))  /* out of range? */)
      {
        fprintf (stderr, "strtod (\"%s\") failed, continuing with test cases.\n\n", double_str);
      }
      else
      {
        i = countof(test_values)-1;
        test_values [i] = double_val;
      }
    }

    for (; i < countof(test_values); i++)
    {
      if (i > 0)
        fputc ('\n', stdout);

      decimal_to_fraction (test_values [i], ref numerator, ref denominator);

      #if HAS_GNU_GMP
      { mpf_t float_number, float_divisor;

        /* 324 * log₂(10) [precision, in bits] */
        mpf_init2 (float_number, 1076);
        mpf_set_z (float_number, numerator);

        mpf_init2 (float_divisor, 1076);
        mpf_set_z (float_divisor, denominator);

        mpf_div (float_number, float_number, float_divisor);  /* result = numerator / denominator */
        mpf_clear (float_divisor);

        gmp_printf ("%Zd / %Zd = %.324Ff\n", numerator, denominator, float_number);

        mpf_clear (float_number);
      }
      #else
      fprintf (stdout, "%lld / %llu = %.19lf\n", numerator, denominator,
                                                 (double)numerator / denominator);
      #endif
    }

    #if HAS_GNU_GMP
    mpz_clears (numerator, denominator, NULL);
    #endif
  }

  return (EXIT_SUCCESS);
}


#if HAS_GNU_GMP
#include "decimal2fraction.c"
#else
#include "decimal2fraction-u64-poc.c"
#endif
