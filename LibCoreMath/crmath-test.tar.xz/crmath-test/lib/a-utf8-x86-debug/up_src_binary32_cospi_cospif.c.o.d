../lib/a-utf8-x86-debug/up_src_binary32_cospi_cospif.c.o: \
 ../src/binary32/cospi/cospif.c
