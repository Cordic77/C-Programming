../lib/a-utf8-x86-release/up_src_binary32_exp_expf.c.o: \
 ../src/binary32/exp/expf.c
