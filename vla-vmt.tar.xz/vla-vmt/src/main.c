#include <stdio.h>       /* (f)printf() */
#include <stdlib.h>      /* malloc(), free(), srand(), rand() */
#include <time.h>        /* time() */


/* Function declarations: */
static void pointer_to_1d_arrays (void);
static void pointer_to_2d_array (void);
static void print_matrix (size_t const rows, size_t const cols,
                          int matrix [rows][cols]);


/* Program entry point: */
int main (void)
{
  /* seed the randomizer */
  srand ((unsigned)time (NULL));

  /* VLAs (“variable-length arrays”) are considered evil nowadays. As
     the following illustrates, however, VMTs (“variably-modified types”)
     do have have their uses: */

  fprintf (stdout, "Matrix as a pointer to a 2-d array:\n");
  pointer_to_2d_array ();  /* One way to do it… */

  fprintf (stdout, "\nMatrix as a pointer to an array of 1-d arrays:\n");
  pointer_to_1d_arrays (); /* … probably the preferable option */

  return (EXIT_SUCCESS);
}


/* Pointer to a dynamically allocated array of 1-d arrays (of ‘cols’ int each) */
static void pointer_to_1d_arrays (void)
{ size_t const rows = 4;
  size_t y, x;

  /* the type of *values is a VLA capturing the number of columns: */
  int (*values) [3] = malloc (rows * sizeof(*values));

  /* … therefore, the number of columns could be calculated like so: */
  size_t const cols = sizeof (*values) / sizeof ((*values) [0]);

  /* populate and output the grid */
  for (y = 0; y < rows; y++)
    for (x = 0; x < cols; x++)
      values [y][x] = rand () % 100;

  /* works because the type of ‘values’ is ‘int (*) [cols]’ (“pointer to an
     array of cols int”) which exactly matches the one expected by the func⹀
     tions ‘matrix’ parameter */
  print_matrix (rows, cols, values);

  /* free allocated memory */
  free (values);
}


/* Pointer to a dynamically allocated 2-d array (with ‘rows’ rows of ‘cols’ int each) */
static void pointer_to_2d_array (void)
{ size_t y, x;

  /* the type of *values is a VLA capturing the number of rows and columns: */
  int (*values) [4][3] = malloc (sizeof (*values));

  /* … therefore, the number of rows/columns could be calculated like so: */
  size_t const rows = sizeof (*values) / sizeof ((*values) [0]);
  size_t const cols = sizeof ((*values) [0]) / sizeof ((*values) [0][0]);

  /* populate and output the grid */
  for (y = 0; y < rows; y++)
    for (x = 0; x < cols; x++)
      (*values) [y][x] = rand () % 100;

  /* works because while the type of ‘*values’ is ‘int[rows][cols]’, the
     compiler will pass the array as a pointer to its first element, i.e.
     ‘int (*)[cols]’ */
  print_matrix (rows, cols, *values);

  /* free allocated memory */
  free (values);
}


/* Outputs the passed matrix in a nicely formatted way. Note that because of
   array decay, the matrix parameter will need to be passed a ‘int (*)[cols]’ */
static void print_matrix (size_t const rows, size_t const cols, int matrix [rows][cols])
{ size_t r, c;

  for (r = 0; r < rows; r++)
  {
    fprintf (stdout, "%-3d", matrix [r][0]);

    for (c = 1; c < cols; c++)
      fprintf (stdout, "  %-3d", matrix [r][c]);

    fputc ('\n', stdout);
  }
}
