../lib/a-utf8-x86-release/up_src_binary64_tanh_tanh.c.o: \
 ../src/binary64/tanh/tanh.c
