../lib/so-utf8-x64-release/up_src_binary64_sin_sin.c.o: \
 ../src/binary64/sin/sin.c
