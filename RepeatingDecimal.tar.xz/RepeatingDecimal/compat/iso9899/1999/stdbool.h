#pragma once
#ifndef _C99_STDBOOL_H_ /* [ */
#define _C99_STDBOOL_H_

#if (defined(_MSC_VER) && _MSC_VER >= 1800) || (defined(__GNUC__) && __GNUC__ >= 3)
/*#error "<stdbool.h> is available since VS2013/GCC 3.0, use the standard header instead!"*/
#include <../include/stdbool.h>   /* (Force inclusion of system header file.) */

#else

/**
 * stdbool.h - ISO C99 Boolean type
 * Author    - Bill Chatfield
 * E-mail    - bill underscore chatfield at yahoo dot com
 * Copyright - You are free to use for any purpose except illegal acts
 * Warrenty  - None: don't blame me if it breaks something
 *
 * In ISO C99, stdbool.h is a standard header and _Bool is a keyword, but
 * some compilers don't offer these yet. This header file is an
 * implementation of the standard ISO C99 stdbool.h header file. It checks
 * for various compiler versions and defines things that are missing in
 * those versions.
 *
 * The GNU and Watcom compilers include a stdbool.h, but the Borland
 * C/C++ 5.5.1 compiler and the Microsoft compilers do not.
 *
 * See http://predef.sourceforge.net/precomp.html for compile macros.
 */
/* https://social.msdn.microsoft.com/Forums/en-US/08e6a3fd-58a3-43b2-ac86-ac4ddd747277/i-cant-use-booleans-in-c#c529fc47-59b8-4566-ae66-ffab5bfa26e0 */
#ifndef __bool_true_false_are_defined
  #if !defined(__cplusplus)
    /**
     * Borland C++ 5.5.1 does not define _Bool.
     */
    #ifdef __BORLANDC__
    typedef int _Bool;
    #endif

    /**
     * Microsoft C/C++ version 14.00.50727.762, which comes with Visual C++ 2005,
     * and version 15.00.30729.01, which comes with Visual C++ 2008, do not
     * define _Bool.
     */
  /*#if defined(_MSC_VER) && _MSC_VER < 1800*/  /* (Already tested.) */
    typedef int _Bool;
  /*#endif*/

    /**
     * Define the Boolean macros only if they are not already defined.
     */
    #ifndef bool
    #define bool  _Bool
    #define false 0
    #define true  1
    #endif
  #else
    #define _Bool bool
  #endif

  #define __bool_true_false_are_defined 1
#endif

#endif

#endif /* _C99_STDBOOL_H_ ] */
