../lib/a-utf8-x86-debug/up_src_binary32_log10p1_log10p1f.c.o: \
 ../src/binary32/log10p1/log10p1f.c
