../lib/a-utf8-x86-release/up_src_binary32_expm1_expm1f.c.o: \
 ../src/binary32/expm1/expm1f.c
