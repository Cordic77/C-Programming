../lib/a-utf8-x86-debug/up_src_binary32_atanh_atanhf.c.o: \
 ../src/binary32/atanh/atanhf.c
