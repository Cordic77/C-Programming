../lib/so-utf8-x64-release/up_src_binary32_log10_log10f.c.o: \
 ../src/binary32/log10/log10f.c
