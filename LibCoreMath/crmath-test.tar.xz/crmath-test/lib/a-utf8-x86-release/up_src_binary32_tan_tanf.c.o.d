../lib/a-utf8-x86-release/up_src_binary32_tan_tanf.c.o: \
 ../src/binary32/tan/tanf.c
