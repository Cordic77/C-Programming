/* The CORE-MATH project

   CORE-MATH Mission: provide on-the-shelf high performance open-source mathematical
   functions with correct rounding that can be integrated into current mathematical
   libraries (GNU libc, Intel Math Library, AMD Libm, Newlib, OpenLibm, Musl, Apple
   Libm, llvm-libc, Microsoft libm, CUDA libm, ROCm)

   user@debian:~$ sudo apt-get install -y libc6 [ libstdc++6 ]

   To be able to compile x86 binaries [x64 only, OPTIONAL]:
   user@debian:~$ sudo apt-get install -y gcc-multilib libc6-i386 [ g++-multilib lib32stdc++6 ]
*/
#ifndef LIB_CORE_MATH_H_
#define LIB_CORE_MATH_H_

/* Function declarations: */
#ifdef __cplusplus
extern "C" {
#endif

  /*  _     _                        _________
     | |__ (_)_ __   __ _ _ __ _   _|___ /___ \
     | '_ \| | '_ \ / _` | '__| | | | |_ \ __) |
     | |_) | | | | | (_| | |  | |_| |___) / __/
     |_.__/|_|_| |_|\__,_|_|   \__, |____/_____|
                               |___/
  */

  /* (hyperbolic) arccosine: */
  float cr_acosf (float x);
  float cr_acoshf (float x);
  float cr_acospif (float x);

  /* (hyperbolic) arcsine: */
  float cr_asinf (float x);
  float cr_asinhf (float x);
  float cr_asinpif (float x);

  /* (hyperbolic) arctangent: */
  float cr_atan2f (float y, float x);
  float cr_atan2pif (float y, float x);
  float cr_atanf (float x);
  float cr_atanhf (float x);
  float cr_atanpif (float x);

  /* cube root: */
  float cr_cbrtf (float x);

  /* (hyperbolic) cosine: */
  float cr_cosf (float x);
  float cr_coshf (float x);
  float cr_cospif (float x);

  /* (complimentary) Gauss error function: */
  float cr_erfcf (float x);
  float cr_erff (float x);

  /* base-10 exponential function: */
  float cr_exp10f (float x);
  float cr_exp10m1f (float x);

  /* base-2 exponential function: */
  float cr_exp2f (float x);
  float cr_exp2m1f (float x);

  /* base-e exponential function: */
  float cr_expf (float x);
  float cr_expm1f (float x);

  /* (Euclidean) distance function: */
  float cr_hypotf (float x, float y);

  /* log gamma function: */
  float cr_lgammaf (float x);

  /* base-10 logarithmic function: */
  float cr_log10f (float x);
  float cr_log10p1f (float x);

  /* log of 1 plus argument: */
  float cr_log1pf (float x);

  /* base-2 logarithmic function: */
  float cr_log2f (float x);
  float cr_log2p1f (float x);

  /* natural logarithmic/power function: */
  float cr_logf (float x);
  float cr_powf (float x0, float y0);

  /* reciprocal square root: */
  float cr_rsqrtf (float x);

  /* calculate sin and cos simultaneously: */
  void  cr_sincosf (float x, float *sout, float *cout);

  /* (hyperbolic) sine: */
  float cr_sinf (float x);
  float cr_sinhf (float x);
  float cr_sinpif (float x);

  /* (hyperbolic) tangent: */
  float cr_tanf (float x);
  float cr_tanhf (float x);
  float cr_tanpif (float x);

  /* true gamma function: */
  float cr_tgammaf (float x);

  /*  _     _                         __   _  _
     | |__ (_)_ __   __ _ _ __ _   _ / /_ | || |
     | '_ \| | '_ \ / _` | '__| | | | '_ \| || |_
     | |_) | | | | | (_| | |  | |_| | (_) |__   _|
     |_.__/|_|_| |_|\__,_|_|   \__, |\___/   |_|
                               |___/
  */

  /* (hyperbolic) arccosine: */
  double cr_acos (double x);
  double cr_acosh (double x);
  double cr_acospi (double x);

  /* (hyperbolic) arcsine: */
  double cr_asin (double x);
  double cr_asinh (double x);
  double cr_asinpi (double x);

  /* (hyperbolic) arctangent: */
  double cr_atan2 (double y, double x);
  double cr_atan2pi (double y, double x);
  double cr_atan (double x);
  double cr_atanh (double x);
  double cr_atanpi (double x);

  /* cube root: */
  double cr_cbrt (double x);

  /* (hyperbolic) cosine: */
  double cr_cos (double x);
  double cr_cosh (double x);
  double cr_cospi (double x);

  /* (complimentary) Gauss error function: */
  double cr_erfc (double x);
  double cr_erf (double x);

  /* base-10 exponential function: */
  double cr_exp10 (double x);
  double cr_exp10m1 (double x);

  /* base-2 exponential function: */
  double cr_exp2 (double x);
  double cr_exp2m1 (double x);

  /* base-e exponential function: */
  double cr_exp (double x);
  double cr_expm1 (double x);

  /* (Euclidean) distance function: */
  double cr_hypot (double x, double y);

  /* log gamma function: */
  double cr_lgamma (double x);

  /* base-10 logarithmic function: */
  double cr_log10 (double x);
  double cr_log10p1 (double x);

  /* log of 1 plus argument: */
  double cr_log1p (double x);

  /* base-2 logarithmic function: */
  double cr_log2 (double x);
  double cr_log2p1 (double x);

  /* natural logarithmic/power function: */
  double cr_log (double x);
  double cr_pow (double x0, double y0);

  /* reciprocal square root: */
  double cr_rsqrt (double x);

  /* calculate sin and cos simultaneously: */
  void  cr_sincos (double x, double *sout, double *cout);

  /* (hyperbolic) sine: */
  double cr_sin (double x);
  double cr_sinh (double x);
  double cr_sinpi (double x);

  /* (hyperbolic) tangent: */
  double cr_tan (double x);
  double cr_tanh (double x);
  double cr_tanpi (double x);

  /* true gamma function: */
  double cr_tgamma (double x);

  /*   ____ _ _    ____                      _
      / ___/ / |  / ___| ___ _ __   ___ _ __(_) ___ ___
     | |   | | | | |  _ / _ \ '_ \ / _ \ '__| |/ __/ __|
     | |___| | | | |_| |  __/ | | |  __/ |  | | (__\__ \
      \____|_|_|  \____|\___|_| |_|\___|_|  |_|\___|___/
  */
  #if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L  /* ISO/IEC 9899:2011 (or later)? */
  #define cr_acos(x)                  _Generic((x), float: cr_acosf,    double: cr_acos)(x)
  #define cr_acosh(x)                 _Generic((x), float: cr_acoshf,   double: cr_acosh)(x)
  #define cr_acospi(x)                _Generic((x), float: cr_acospif,  double: cr_acospi)(x)

  #define cr_asin(x)                  _Generic((x), float: cr_asinf,    double: cr_asin)(x)
  #define cr_asinh(x)                 _Generic((x), float: cr_asinhf,   double: cr_asinh)(x)
  #define cr_asinpi(x)                _Generic((x), float: cr_asinpif,  double: cr_asinpi)(x)

  #define cr_atan2(y, x)              _Generic((x), float: cr_atan2f,   double: cr_atan2)(y, x)
  #define cr_atan2pi(y, x)            _Generic((x), float: cr_atan2pif, double: cr_atan2pi)(y, x)
  #define cr_atan(x)                  _Generic((x), float: cr_atanf,    double: cr_atan)(x)
  #define cr_atanh(x)                 _Generic((x), float: cr_atanhf,   double: cr_atanh)(x)
  #define cr_atanpi(x)                _Generic((x), float: cr_atanpif,  double: cr_atanpi)(x)

  #define cr_cbrt(x)                  _Generic((x), float: cr_cbrtf,    double: cr_cbrt)(x)

  #define cr_cos(x)                   _Generic((x), float: cr_cosf,     double: cr_cos)(x)
  #define cr_cosh(x)                  _Generic((x), float: cr_coshf,    double: cr_cosh)(x)
  #define cr_cospi(x)                 _Generic((x), float: cr_cospif,   double: cr_cospi)(x)

  #define cr_erfc(x)                  _Generic((x), float: cr_erfcf,    double: cr_erfc)(x)
  #define cr_erf(x)                   _Generic((x), float: cr_erff,     double: cr_erf)(x)

  #define cr_exp10(x)                 _Generic((x), float: cr_exp10f,   double: cr_exp10)(x)
  #define cr_exp10m1(x)               _Generic((x), float: cr_exp10m1f, double: cr_exp10m1)(x)

  #define cr_exp2(x)                  _Generic((x), float: cr_exp2f,    double: cr_exp2)(x)
  #define cr_exp2m1(x)                _Generic((x), float: cr_exp2m1f,  double: cr_exp2m1)(x)

  #define cr_exp(x)                   _Generic((x), float: cr_expf,     double: cr_exp)(x)
  #define cr_expm1(x)                 _Generic((x), float: cr_expm1f,   double: cr_expm1)(x)

  #define cr_hypot(x, y)              _Generic((x), float: cr_hypotf,   double: cr_hypot)(x, y)

  #define cr_lgamma(x)                _Generic((x), float: cr_lgammaf,  double: cr_lgamma)(x)

  #define cr_log10(x)                 _Generic((x), float: cr_log10f,   double: cr_log10)(x)
  #define cr_log10p1(x)               _Generic((x), float: cr_log10p1f, double: cr_log10p1)(x)

  #define cr_log1p(x)                 _Generic((x), float: cr_log1pf,   double: cr_log1p)(x)

  #define cr_log2(x)                  _Generic((x), float: cr_log2f,    double: cr_log2)(x)
  #define cr_log2p1(x)                _Generic((x), float: cr_log2p1f,  double: cr_log2p1)(x)

  #define cr_log(x)                   _Generic((x), float: cr_logf,     double: cr_log)(x)
  #define cr_pow(x0, y0)              _Generic((x), float: cr_powf,     double: cr_pow)(x0, y0)

  #define cr_rsqrt(x)                 _Generic((x), float: cr_rsqrtf,   double: cr_rsqrt)(x)

  #define cr_sincosf(x, sout, cout)   _Generic((x), float: cr_sincosf,  double: cr_sincos)(x, sout, cout)

  #define cr_sin(x)                   _Generic((x), float: cr_sinf,     double: cr_sin)(x)
  #define cr_sinh(x)                  _Generic((x), float: cr_sinhf,    double: cr_sinh)(x)
  #define cr_sinpi(x)                 _Generic((x), float: cr_sinpif,   double: cr_sinpi)(x)

  #define cr_tan(x)                   _Generic((x), float: cr_tanf,     double: cr_tan)(x)
  #define cr_tanh(x)                  _Generic((x), float: cr_tanhf,    double: cr_tanh)(x)
  #define cr_tanpi(x)                 _Generic((x), float: cr_tanpif,   double: cr_tanpi)(x)

  #define cr_tgamma(x)                _Generic((x), float: cr_tgammaf,  double: cr_tgamma)(x)
  #endif

#ifdef __cplusplus
}
#endif

#endif
