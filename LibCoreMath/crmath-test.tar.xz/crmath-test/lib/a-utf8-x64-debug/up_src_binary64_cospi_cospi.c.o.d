../lib/a-utf8-x64-debug/up_src_binary64_cospi_cospi.c.o: \
 ../src/binary64/cospi/cospi.c
