../lib/so-utf8-x64-debug/up_src_binary32_cospi_cospif.c.o: \
 ../src/binary32/cospi/cospif.c
