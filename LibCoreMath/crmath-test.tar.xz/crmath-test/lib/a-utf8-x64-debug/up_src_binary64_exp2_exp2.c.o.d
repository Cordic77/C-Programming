../lib/a-utf8-x64-debug/up_src_binary64_exp2_exp2.c.o: \
 ../src/binary64/exp2/exp2.c
