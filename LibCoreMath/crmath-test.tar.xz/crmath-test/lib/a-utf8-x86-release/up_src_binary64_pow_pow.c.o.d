../lib/a-utf8-x86-release/up_src_binary64_pow_pow.c.o: \
 ../src/binary64/pow/pow.c ../src/binary64/pow/pow.h \
 ../src/binary64/pow/dint.h ../src/binary64/pow/qint.h
../src/binary64/pow/pow.h:
../src/binary64/pow/dint.h:
../src/binary64/pow/qint.h:
