../lib/so-utf8-x64-release/up_src_binary64_log1p_log1p.c.o: \
 ../src/binary64/log1p/log1p.c
