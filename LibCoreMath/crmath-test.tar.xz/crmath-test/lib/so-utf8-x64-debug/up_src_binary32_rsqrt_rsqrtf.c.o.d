../lib/so-utf8-x64-debug/up_src_binary32_rsqrt_rsqrtf.c.o: \
 ../src/binary32/rsqrt/rsqrtf.c
