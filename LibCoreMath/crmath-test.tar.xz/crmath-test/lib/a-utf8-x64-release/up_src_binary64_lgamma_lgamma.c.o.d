../lib/a-utf8-x64-release/up_src_binary64_lgamma_lgamma.c.o: \
 ../src/binary64/lgamma/lgamma.c
