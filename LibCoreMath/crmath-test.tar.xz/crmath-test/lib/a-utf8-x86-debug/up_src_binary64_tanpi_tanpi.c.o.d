../lib/a-utf8-x86-debug/up_src_binary64_tanpi_tanpi.c.o: \
 ../src/binary64/tanpi/tanpi.c
