../lib/so-utf8-x64-debug/up_src_binary32_acospi_acospif.c.o: \
 ../src/binary32/acospi/acospif.c
