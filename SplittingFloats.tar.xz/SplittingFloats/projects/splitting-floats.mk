##
## Auto Generated makefile by CodeLite IDE
## any manual changes will be erased      
##
## a-utf8-x64-release
ProjectName            :=splitting-floats
ConfigurationName      :=a-utf8-x64-release
WorkspaceConfiguration :=a-utf8-x64-release
WorkspacePath          :=/home/linuser/Projects/ProgC/SplittingFloats/projects
ProjectPath            :=/home/linuser/Projects/ProgC/SplittingFloats/projects
IntermediateDirectory  :=../bin/a-utf8-x64-release/codelite
OutDir                 := $(IntermediateDirectory)
CurrentFileName        :=
CurrentFilePath        :=
CurrentFileFullPath    :=
User                   :=linuser
Date                   :=11/02/2026
CodeLitePath           :=/home/linuser/.codelite
LinkerName             :=/usr/bin/g++
SharedObjectLinkerName :=/usr/bin/g++ -shared -fPIC
ObjectSuffix           :=.o
DependSuffix           :=.o.d
PreprocessSuffix       :=.i
DebugSwitch            :=-g 
IncludeSwitch          :=-I
LibrarySwitch          :=-l
OutputSwitch           :=-o 
LibraryPathSwitch      :=-L
PreprocessorSwitch     :=-D
SourceSwitch           :=-c 
OutputDirectory        :=$(IntermediateDirectory)/..
OutputFile             :=$(IntermediateDirectory)/../$(ProjectName)
Preprocessors          :=$(PreprocessorSwitch)NDEBUG 
ObjectSwitch           :=-o 
ArchiveOutputSwitch    := 
PreprocessOnlySwitch   :=-E
ObjectsFileList        :="splitting-floats.txt"
PCHCompileFlags        :=
MakeDirCommand         :=mkdir -p
LinkOptions            :=  -m64 -z noexecstack -Wl,-Bstatic -Wl,-Bdynamic
IncludePath            :=  $(IncludeSwitch). $(IncludeSwitch)$(ProjectPath)/../include/compat $(IncludeSwitch)$(ProjectPath)/../include $(IncludeSwitch). 
IncludePCH             := 
RcIncludePath          := 
Libs                   := 
ArLibs                 :=  
LibPath                := $(LibraryPathSwitch)$(OutDir) 

##
## Common variables
## AR, CXX, CC, AS, CXXFLAGS and CFLAGS can be overridden using an environment variable
##
AR       := /usr/bin/ar rcu
CXX      := /usr/bin/g++
CC       := /usr/bin/gcc
CXXFLAGS := -std=c2x -D_FORTIFY_SOURCE=2 -fpie -Wl,-pie -fno-omit-frame-pointer -fstack-protector -fcf-protection -fwrapv -fno-strict-aliasing -fno-delete-null-pointer-checks -fno-tree-vrp -fno-builtin -fno-unsafe-math-optimizations -grecord-gcc-switches -Wall -Wextra -Werror -fno-omit-frame-pointer -Wl,-z,defs -Wl,-z,now -Wl,-z,relro -m64 -O2 $(Preprocessors)
CFLAGS   := -std=c2x -D_FORTIFY_SOURCE=2 -fpie -Wl,-pie -fno-omit-frame-pointer -fstack-protector -fcf-protection -fwrapv -fno-strict-aliasing -fno-delete-null-pointer-checks -fno-tree-vrp -fno-builtin -fno-unsafe-math-optimizations -grecord-gcc-switches -Wall -Wextra -Werror -fno-omit-frame-pointer -Wl,-z,defs -Wl,-z,now -Wl,-z,relro -m64 -O2 $(Preprocessors)
ASFLAGS  := 
AS       := /usr/bin/as


##
## User defined environment variables
##
CodeLiteDir:=/usr/share/codelite
Objects0=$(IntermediateDirectory)/up_src_splitting-floats.c$(ObjectSuffix) 



Objects=$(Objects0) 

##
## Main Build Targets 
##
.PHONY: all clean PreBuild PrePreBuild PostBuild MakeIntermediateDirs
all: $(OutputFile)

$(OutputFile): $(IntermediateDirectory)/.d $(Objects) 
	@$(MakeDirCommand) $(@D)
	@echo "" > $(IntermediateDirectory)/.d
	@echo $(Objects0)  > $(ObjectsFileList)
	$(LinkerName) $(OutputSwitch)$(OutputFile) @$(ObjectsFileList) $(LibPath) $(Libs) $(LinkOptions)

MakeIntermediateDirs:
	@test -d ../bin/a-utf8-x64-release/codelite || $(MakeDirCommand) ../bin/a-utf8-x64-release/codelite


$(IntermediateDirectory)/.d:
	@test -d ../bin/a-utf8-x64-release/codelite || $(MakeDirCommand) ../bin/a-utf8-x64-release/codelite

PreBuild:


##
## Objects
##
$(IntermediateDirectory)/up_src_splitting-floats.c$(ObjectSuffix): ../src/splitting-floats.c
	@$(CC) $(CFLAGS) $(IncludePath) -MG -MP -MT$(IntermediateDirectory)/up_src_splitting-floats.c$(ObjectSuffix) -MF$(IntermediateDirectory)/up_src_splitting-floats.c$(DependSuffix) -MM ../src/splitting-floats.c
	$(CC) $(SourceSwitch) "/home/linuser/Projects/ProgC/SplittingFloats/src/splitting-floats.c" $(CFLAGS) $(ObjectSwitch)$(IntermediateDirectory)/up_src_splitting-floats.c$(ObjectSuffix) $(IncludePath)
$(IntermediateDirectory)/up_src_splitting-floats.c$(PreprocessSuffix): ../src/splitting-floats.c
	$(CC) $(CFLAGS) $(IncludePath) $(PreprocessOnlySwitch) $(OutputSwitch) $(IntermediateDirectory)/up_src_splitting-floats.c$(PreprocessSuffix) ../src/splitting-floats.c


-include $(IntermediateDirectory)/*$(DependSuffix)
##
## Clean
##
clean:
	$(RM) -r ../bin/a-utf8-x64-release/codelite/


