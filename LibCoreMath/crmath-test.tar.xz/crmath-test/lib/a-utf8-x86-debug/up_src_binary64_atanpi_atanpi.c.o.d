../lib/a-utf8-x86-debug/up_src_binary64_atanpi_atanpi.c.o: \
 ../src/binary64/atanpi/atanpi.c
