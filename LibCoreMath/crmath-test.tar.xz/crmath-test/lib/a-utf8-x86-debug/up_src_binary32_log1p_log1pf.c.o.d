../lib/a-utf8-x86-debug/up_src_binary32_log1p_log1pf.c.o: \
 ../src/binary32/log1p/log1pf.c
