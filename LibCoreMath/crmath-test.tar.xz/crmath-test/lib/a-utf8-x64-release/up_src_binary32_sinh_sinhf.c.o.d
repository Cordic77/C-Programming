../lib/a-utf8-x64-release/up_src_binary32_sinh_sinhf.c.o: \
 ../src/binary32/sinh/sinhf.c
