../lib/a-utf8-x64-debug/up_src_binary64_sincos_sincos.c.o: \
 ../src/binary64/sincos/sincos.c
