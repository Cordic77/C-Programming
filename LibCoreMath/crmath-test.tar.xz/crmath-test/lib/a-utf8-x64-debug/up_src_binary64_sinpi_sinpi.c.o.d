../lib/a-utf8-x64-debug/up_src_binary64_sinpi_sinpi.c.o: \
 ../src/binary64/sinpi/sinpi.c
