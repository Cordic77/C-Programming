../lib/a-utf8-x64-debug/up_src_binary64_atanh_atanh.c.o: \
 ../src/binary64/atanh/atanh.c
