../lib/a-utf8-x86-debug/up_src_binary64_exp_exp.c.o: \
 ../src/binary64/exp/exp.c
