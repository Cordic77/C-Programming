../lib/a-utf8-x86-release/up_src_binary64_exp10m1_exp10m1.c.o: \
 ../src/binary64/exp10m1/exp10m1.c
