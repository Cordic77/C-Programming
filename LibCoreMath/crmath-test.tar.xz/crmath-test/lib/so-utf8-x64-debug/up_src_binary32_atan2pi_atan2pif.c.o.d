../lib/so-utf8-x64-debug/up_src_binary32_atan2pi_atan2pif.c.o: \
 ../src/binary32/atan2pi/atan2pif.c
