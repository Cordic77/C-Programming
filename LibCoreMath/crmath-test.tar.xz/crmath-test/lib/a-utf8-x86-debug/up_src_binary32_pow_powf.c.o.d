../lib/a-utf8-x86-debug/up_src_binary32_pow_powf.c.o: \
 ../src/binary32/pow/powf.c
