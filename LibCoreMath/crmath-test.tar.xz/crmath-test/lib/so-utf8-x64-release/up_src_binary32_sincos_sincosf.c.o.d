../lib/so-utf8-x64-release/up_src_binary32_sincos_sincosf.c.o: \
 ../src/binary32/sincos/sincosf.c
