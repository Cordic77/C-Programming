../lib/so-utf8-x64-release/up_src_binary32_log1p_log1pf.c.o: \
 ../src/binary32/log1p/log1pf.c
