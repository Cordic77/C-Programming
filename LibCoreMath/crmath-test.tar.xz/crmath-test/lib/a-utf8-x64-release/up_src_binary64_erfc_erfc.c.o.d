../lib/a-utf8-x64-release/up_src_binary64_erfc_erfc.c.o: \
 ../src/binary64/erfc/erfc.c
