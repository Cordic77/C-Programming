#include <stdio.h>                /* snprintf() */
#include <stdlib.h>               /* strtoull() */
#include <errno.h>                /* extern int errno; */
#include <string.h>               /* strchr() */
#include <ctype.h>                /* isdigit() */
#include <limits.h>               /* LLONG_MIN, LLONG_MAX */
#include <math.h>                 /* pow() */

#include "stdint.h"               /* (u)int64_t */

#include "stdcountof.h"           /* countof() */

/* MSVC compatibility: */
#if defined(_MSC_VER) && _MSC_VER < 1800  /* < VS2013? */
#define strtoll _strtoi64
#endif

#if defined(_MSC_VER) && _MSC_VER < 1900  /* < VS2015? */
#define snprintf _snprintf
#endif


/* double values, when printed, can get quite large:

DBL_MAX = 2¹⁰²⁴ - 2¹⁰²⁴⁻⁵³, req. a total of (311+1) chars:
+17976931348623157081452742373170435679807056752584499659891747680315726078002853876058955863276687817154045895351438246423432132688946418276846754670353751698604991057655128207624549009038932894407586850845513394230458323690322294816580855933212334827479782620414472316873817718091929988125040402618412485836.00000000000000000

DBL_MIN = -2¹⁰²², req. a total of (327+1) chars:
-0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022250738585072014

   Taken together this means we may need to reserve (635+1) chars to be able
   to handle large (positive) as well as small (negative) numbers:
*/
typedef char double_string [635+1];


/* Forward declarations: */
static void
  double_to_string (double const double_val, double_string double_str);
static void
  simplify_repeating_decimals (double_string double_str, size_t nz_digit, uint64_t *integral, uint64_t *divisor);
static void
  divide_by_gcd (uint64_t *numerator, uint64_t *denominator);


/* Returns the ‘numerator’ and ‘denominator’ of a fraction that should
   result in ‘double_val’ if evaluated.
*/
int decimal_to_fraction (double const double_val, int64_t *numerator, uint64_t *denominator)
{ double_string
    double_str;             /* double_val converted to a string */

  /* float → string coversion: */
  double_to_string (double_val, double_str);

  /* Is it an integral number? */
  { size_t decimal_point_index,
           fractional_digits;

    { char const *decimal_point = strchr (double_str, '.');

      if (decimal_point == NULL)  /* Has no fractional part? */
      { char *endptr;

        errno = 0;
       *numerator = strtoll (double_str, &endptr, 10);
        if ((endptr == double_str)  /* nothing parsed from the string? */
         || (errno == ERANGE && (*numerator == LLONG_MAX || *numerator == LLONG_MIN))  /* out of range? */)
        {
         *numerator = 0;
          return (0);
        }

       *denominator = 1;
        return (1);
      }

      decimal_point_index = (size_t)(decimal_point - double_str);
      fractional_digits = strlen (double_str + decimal_point_index + 1);

      memmove (double_str + decimal_point_index,
               double_str + decimal_point_index + 1,
               fractional_digits + 1);
    }

    /* Find first non-zero digit in the fractional part: */
    { size_t nz_digit = decimal_point_index;

      while (double_str [nz_digit] == '0')
        nz_digit++;

      /* Power of 10 to multiply with to get to a whole number? */
      { uint64_t
          integral,         /* double_val converted to an integral */
          divisor;          /* value (initially a power of 10) ‘double_val’ was scaled by */

        int sign = (double_str [0] == '-')? -1 : +1;

        /* Calculate the ‘denominator’ as a power of 2: */
        divisor = (uint64_t)pow (10.0, (double)fractional_digits);
        integral = (uint64_t)(sign * double_val * divisor);

        /* Test for repeating decimals at the end of the digit string: */
        simplify_repeating_decimals (double_str, nz_digit, &integral, &divisor);

        /* Divide ‘integral_val’ and ‘power_10’ by their GCD to reduce them to smaller numbers: */
        divide_by_gcd (&integral, &divisor);

       *numerator = sign*integral;
       *denominator = divisor;
        return (1);
      }
    }
  }
}


static void double_to_string (double const double_val, double_string double_str)
{
  /* Get string representation for given ‘double_val’: */
  #ifdef _MSC_VER  /* Doesnʼt support "%.324lf", chokes up on it: */
  snprintf (double_str, 635, "%.13lf", double_val);
  #else
  snprintf (double_str, 635, "%.13lf" /*"%.324lf"*/, double_val);  /* (power_10 will overflow otherwise.) */
  #endif

  /* Remove fractional zeroes at the end, if any: */
  { char *decimal_point = strchr (double_str, '.');

    if (decimal_point)
    {
      char *fractional_digits = strchr (decimal_point+1, '\0') - 1;

      while (*fractional_digits == '0')
       *fractional_digits-- = '\0';

      if (*fractional_digits == '.')
       *fractional_digits = '\0';
    }
  }
}


/* Function capable of detecting repeating decimals with a period of up to 6.

  The function assumes that a periodicity exists when a sequence of digits is
  repeated twice. As such, the following implementation is not a reliable one
  but more of a heuristic.
*/
#define MAX_REPEATING_DECIMAL_PERIOD  6   /* check for repeating decimals of a period up to 6 digits */
#define STRIP_DIGITS_PLACES           1   /* strip off digits at the end of ‘double_str’ */
#define STRIP_DIGITS_DIVISOR         10   /* … by dividing the given ‘integral’ value */

static void simplify_repeating_decimals (double_string double_str, size_t nz_digit, uint64_t *integral, uint64_t *divisor)
{ size_t displacement, i;

  size_t digit_string_len = strlen (double_str + nz_digit);

  digit_string_len -= STRIP_DIGITS_PLACES;                /* We require ‘2*MAX_PERIOD + STRIP_DIGITS_PLACES’ digits… assuming the last */
  if (digit_string_len < 2*MAX_REPEATING_DECIMAL_PERIOD)  /* digit in the decimal expansion may be rounded (and thus not a match) */
    return;

  for (displacement = 1; displacement <= MAX_REPEATING_DECIMAL_PERIOD; displacement++)
  {
    size_t last_index = nz_digit + digit_string_len - STRIP_DIGITS_PLACES,
           must_match = 2 * displacement;

    if (must_match < MAX_REPEATING_DECIMAL_PERIOD)
      must_match = (3 * MAX_REPEATING_DECIMAL_PERIOD) / 2;

    for (i = last_index - displacement; i >= nz_digit; i--)
    {
      if (double_str [i + displacement] != double_str [i])
        break;
    }

    if (last_index - i >= must_match)
    {
      uint64_t strip_ulp = *integral / STRIP_DIGITS_DIVISOR;
      uint64_t power_10 = (uint64_t)pow (10.0, (double)displacement);

      uint64_t repeating = strip_ulp % power_10;

      uint64_t numerator = strip_ulp * power_10;
      numerator = numerator + repeating;

      *integral = (numerator - strip_ulp) * STRIP_DIGITS_DIVISOR;
      *divisor *= (power_10 - 1);
       return;
    }
  }
}


/* Simplify the given fraction by dividing the given numerator
   and denominator by their GCD (“greatest common divisor”).
*/
static void divide_by_gcd (uint64_t *numerator, uint64_t *denominator)
{ uint64_t a = *numerator, b = *denominator;

/*assert (a != 0 && b != 0);*/

  { uint64_t x = a, y = b;

    while (y != 0)
    {
      uint64_t r = x % y;
      x = y;
      y = r;
    }

    /* Divide both by x == gcd(a, b): */
    *numerator   = a / x;
    *denominator = b / x;
  }
}
