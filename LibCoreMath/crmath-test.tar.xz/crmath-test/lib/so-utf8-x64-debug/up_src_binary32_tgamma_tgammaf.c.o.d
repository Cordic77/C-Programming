../lib/so-utf8-x64-debug/up_src_binary32_tgamma_tgammaf.c.o: \
 ../src/binary32/tgamma/tgammaf.c
