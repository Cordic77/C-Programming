#pragma once
#ifndef _C28_COUNTOF_H_ /* [ */
#define _C28_COUNTOF_H_

#if __STDC_VERSION__ < 202312L  /*FIXME once the next standard after C23 is released */
  /* Results! - The Big Array Size Survey for C. “C26” (?) will have a countof() operator: */
  #if (!defined(__STDC_VERSION__) || __STDC_VERSION__ <= 202311L) && !defined(countof)
  #define countof(arr)  (sizeof(arr)/sizeof((arr)[0]))
  #endif
#endif

#endif /* _C28_COUNTOF_H_ ] */
