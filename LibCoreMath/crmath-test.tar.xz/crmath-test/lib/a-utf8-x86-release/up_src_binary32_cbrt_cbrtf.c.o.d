../lib/a-utf8-x86-release/up_src_binary32_cbrt_cbrtf.c.o: \
 ../src/binary32/cbrt/cbrtf.c
