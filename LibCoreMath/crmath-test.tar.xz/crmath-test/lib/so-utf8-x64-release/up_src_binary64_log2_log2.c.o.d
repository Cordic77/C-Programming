../lib/so-utf8-x64-release/up_src_binary64_log2_log2.c.o: \
 ../src/binary64/log2/log2.c
