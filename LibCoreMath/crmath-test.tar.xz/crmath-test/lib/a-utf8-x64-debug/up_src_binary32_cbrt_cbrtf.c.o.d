../lib/a-utf8-x64-debug/up_src_binary32_cbrt_cbrtf.c.o: \
 ../src/binary32/cbrt/cbrtf.c
