../lib/a-utf8-x86-debug/up_src_binary64_exp10_exp10.c.o: \
 ../src/binary64/exp10/exp10.c
