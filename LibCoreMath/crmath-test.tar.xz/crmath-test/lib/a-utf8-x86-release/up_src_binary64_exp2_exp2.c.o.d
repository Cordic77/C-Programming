../lib/a-utf8-x86-release/up_src_binary64_exp2_exp2.c.o: \
 ../src/binary64/exp2/exp2.c
