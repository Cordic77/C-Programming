../lib/a-utf8-x86-debug/up_src_binary64_hypot_hypot.c.o: \
 ../src/binary64/hypot/hypot.c
