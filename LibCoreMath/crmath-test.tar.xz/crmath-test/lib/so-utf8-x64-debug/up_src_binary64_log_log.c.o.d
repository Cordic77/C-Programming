../lib/so-utf8-x64-debug/up_src_binary64_log_log.c.o: \
 ../src/binary64/log/log.c ../src/binary64/log/dint.h
../src/binary64/log/dint.h:
