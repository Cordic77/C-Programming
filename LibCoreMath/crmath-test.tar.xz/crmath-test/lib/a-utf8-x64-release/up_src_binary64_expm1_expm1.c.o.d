../lib/a-utf8-x64-release/up_src_binary64_expm1_expm1.c.o: \
 ../src/binary64/expm1/expm1.c
