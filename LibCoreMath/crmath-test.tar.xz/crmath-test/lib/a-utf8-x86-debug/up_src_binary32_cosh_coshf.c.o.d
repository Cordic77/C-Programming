../lib/a-utf8-x86-debug/up_src_binary32_cosh_coshf.c.o: \
 ../src/binary32/cosh/coshf.c
