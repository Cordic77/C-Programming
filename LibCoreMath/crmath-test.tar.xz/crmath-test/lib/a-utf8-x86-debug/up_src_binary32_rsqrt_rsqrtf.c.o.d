../lib/a-utf8-x86-debug/up_src_binary32_rsqrt_rsqrtf.c.o: \
 ../src/binary32/rsqrt/rsqrtf.c
