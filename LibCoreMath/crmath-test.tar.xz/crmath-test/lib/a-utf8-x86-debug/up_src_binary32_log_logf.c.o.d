../lib/a-utf8-x86-debug/up_src_binary32_log_logf.c.o: \
 ../src/binary32/log/logf.c
