../lib/a-utf8-x86-debug/up_src_binary32_tanh_tanhf.c.o: \
 ../src/binary32/tanh/tanhf.c
