../lib/a-utf8-x64-debug/up_src_binary64_atanpi_atanpi.c.o: \
 ../src/binary64/atanpi/atanpi.c
