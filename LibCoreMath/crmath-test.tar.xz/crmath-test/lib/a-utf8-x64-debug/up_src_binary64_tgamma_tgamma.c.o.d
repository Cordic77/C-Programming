../lib/a-utf8-x64-debug/up_src_binary64_tgamma_tgamma.c.o: \
 ../src/binary64/tgamma/tgamma.c
