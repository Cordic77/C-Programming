../lib/so-utf8-x64-debug/up_src_binary32_acos_acosf.c.o: \
 ../src/binary32/acos/acosf.c
