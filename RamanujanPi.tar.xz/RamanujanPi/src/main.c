#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#if defined(_WIN32)
  #include <mpir.h>    /* MPIR (Multiple Precision Integers and Rationals) is
                          a fork of the GMP (GNU Multi Precision) project. */

  #if _MSC_VER < 1900  /* Visual Studio 2015 finally comes with snprintf() */
  #define snprintf _snprintf
  #endif
#else
  #include <gmp.h>
#endif

#include "iso9899/stdcountof.h"


/* Function declafractionns: */
static mp_bitcnt_t
  digits_to_bits (mp_limb_t decimal_digits);
static void
  compute_pi_ramanujan (mpf_t pi, mp_limb_t decimal_digits);
static double
  compute_pi_ramanujan_double (size_t decimal_digits);


/* Program entry point: */
int main (int argc, char *argv [])
{ mp_limb_t decimal_digits = 100;  /* default to one hundred digits of π */

  if (argc > 1)
  { char *end = NULL;

    decimal_digits = strtoul (argv [1], &end, 10);

    if (end == argv[1] || *end != '\0' || decimal_digits == 0)
    {
      fprintf (stderr, "Usage: %s [decimal-digits]\n", argv [0]);
      return (EXIT_FAILURE);
    }
  }

  /* With doubleʼs, Ramanujanʼs 1/π series only makes sense for k up to 2. */
  { double pi = compute_pi_ramanujan_double (15);

    fprintf (stdout, "pi_dbl = %.15lf\n", pi);
  }

  /* Set the default precision to be at least ‘bit_precision’ bits.
     All subsequent calls to ‘mpf_init()’ will use this precision. */
  { mp_bitcnt_t bit_precision = digits_to_bits (decimal_digits);

    mpf_set_default_prec (bit_precision);
  }

  /* Finally, the actual computation: */
  { mpf_t pi;
    mpf_init (pi);

    compute_pi_ramanujan (pi, decimal_digits);

    /* … and print the result to stdout: */
    { char format_string [64];
      snprintf (format_string, countof(format_string),
                "pi_gmp = %%.%lluFf\n", (unsigned long long)decimal_digits);
      gmp_printf (format_string, pi);
    }

    mpf_clear (pi);
  }

  return (EXIT_SUCCESS);
}


/* Multiplies ‘decimal_digits’, the number of decimal places the caller of
   this function wants, by a fraction approximating log₂(10) to obtain the
   ‘bit precision’ that will have to be passed to ‘mpf_set_default_prec()’.

   As 108853/32768 (=3.321929931640625) gives a suprisingly good approximation
   of log₂(10), off by only about 0.000001836753262652, this can be done by a
   mulitplication followed by a simple right shift.

   When calculating π to high precision, one typically needs log₂(N) guard
   bits, where N is the number of digits being calculated. Below, the fixed
   constant 64 was chosen instead.
*/
static mp_bitcnt_t digits_to_bits (mp_limb_t decimal_digits)
{
  return (((decimal_digits * (mp_bitcnt_t)108853 + 32768-1) >> 15) + 64);
}


/* The following function relies on Ramanujanʼs 1/π series,

   \frac{1}{\pi} = \frac{2\sqrt{2}}{9801} \sum_{k=0}^{\infty} \frac{(4k)!(1103 + 26390k)}{(k!)^4 396^{4k}}

   as well as MPIRʼs ‘mpf_t’ data type (for arbitrary-precision floating-point
   numbers).

   The computationally expensive part of this formula is the following bit:

          (4·k)!
   sₖ = ━━━━━━━━━━━
        (k!)⁴·396⁴ᵏ

   Rewritten in the form of a recurrence equation the sₖ can be calculated
   as follows:

   s₀ = 1

             (4k+1)(4k+2)(4k+3)(4k+4)
   sₖ₊₁ = sₖ·━━━━━━━━━━━━━━━━━━━━━━━━
                   (k+1)⁴·396⁴

   With that, the given sum becomes

   \frac{1}{\pi} = \frac{2\sqrt{2}}{9801} \sum_{k=0}^{\infty} (1103 + 26390k)s_k

   Using Stirlingʼs approximation for factorials, the fraction of consecutive
   terms of this sum is roughly equal to 256 ÷ 396⁴ = 1 ÷ 96,059,601 ≈ 10⁻⁸,
   providing the rapid convergence noted by Ramanujan.
*/
#define RAMANUJAN_SATO_A        1103ul  /* Ramanujan-Sato A parameter, related to g₅₈ g-invariant */
#define LINEAR_COEFFICIENT_B   26390ul  /* Linear coefficient, derived from singular modulus d = 58 */
#define MODULAR_DENOMINATOR     9801ul  /* 99² */
#define CONVERGENCE_BASE_SQ   156816ul  /* [4×99 (related to j-invariant)]² */

static void compute_pi_ramanujan (mpf_t pi, mp_limb_t decimal_digits)
{ mpf_t sum;
  mpf_init (sum);

  { /* epsilon = 10⁻⁽ᵈᵉᶜⁱᵐᵃˡᵈⁱᵍᵗˢ⁺⁸⁾ */
    mpf_t epsilon;
    mpf_init (epsilon);

    { mpz_t decimal_places_pow10;
      mpz_init (decimal_places_pow10);

      /* Each term of this series is about 1÷96,059,601 as large as the previ⹀
         ous one. Once the target precision is reached, the given ‘⁺⁸’ should
         therefore result in one additional term being calculated (and added): */
      mpz_ui_pow_ui (decimal_places_pow10, 10, decimal_digits+8);  /* mpz_t = 10ᵈᵉᶜⁱᵐᵃˡᵈⁱᵍᵗˢ⁺⁸ */
      mpf_set_z (epsilon, decimal_places_pow10);                   /* mpf_t = mpz_t */
      mpf_ui_div (epsilon, 1, epsilon);                            /* epsilon = 1 ÷ mpf_t */

      mpz_clear (decimal_places_pow10);
    }

    /* Sum up the individual terms until they become smaller than the calculated ε: */
    { size_t k = 0;
      mpf_t term;
      mpf_t s_k, fraction;

      /* Initialize ‘s₀’ to 1 and ‘sum’ to 0: */
      mpf_inits (term, s_k, fraction, NULL);
      mpf_set_ui (s_k, 1);

      mpf_set_ui (sum, 0);

      for (k = 0; ; ++k)
      {
        /* term = (1103 + 26390k) * sₖ */
        mpf_set (term, s_k);
        mpf_mul_ui (term, term, RAMANUJAN_SATO_A + LINEAR_COEFFICIENT_B * k);

        if (mpf_cmp (term, epsilon) <= 0)
          break;

        /* \sum += term */
        mpf_add (sum, sum, term);

        /* sₖ₊₁ = sₖ·(4k+1)(4k+2)(4k+3)(4k+4) / (k+1)⁴·396⁴ */
        { mp_limb_t signature_index = 4 * k;

          mpf_set_ui (fraction, signature_index + 1);
          mpf_mul_ui (fraction, fraction, signature_index + 2);
          mpf_mul_ui (fraction, fraction, signature_index + 3);
          mpf_mul_ui (fraction, fraction, signature_index + 4);

          /* Denominator: */
          { mp_limb_t index_plus_1 = k + 1;

            mpf_div_ui (fraction, fraction, index_plus_1);
            mpf_div_ui (fraction, fraction, index_plus_1);
            mpf_div_ui (fraction, fraction, index_plus_1);
            mpf_div_ui (fraction, fraction, index_plus_1);
          }

          /* Divide by 396⁴: */
          mpf_div_ui (fraction, fraction, CONVERGENCE_BASE_SQ);
          mpf_div_ui (fraction, fraction, CONVERGENCE_BASE_SQ);

          /* sₖ₊₁ = sₖ·fraction */
          mpf_mul (s_k, s_k, fraction);
        }
      }

      mpf_clears (term, s_k, fraction, NULL);
    }

    mpf_clear (epsilon);
  }

  /* factor = 2*sqrt(2) ÷ 9801; sum *= factor; */
  { mpf_t factor;
    mpf_init (factor);

    mpf_sqrt_ui (factor, 2);
    mpf_mul_ui (factor, factor, 2);
    mpf_div_ui (factor, factor, MODULAR_DENOMINATOR);
    mpf_mul (sum, sum, factor);

    mpf_clear (factor);
  }

  /* π = 1 ÷ sum */
  mpf_ui_div (pi, 1, sum);
  mpf_clear (sum);
}


static double compute_pi_ramanujan_double (size_t decimal_digits)
{ double sum = 0.0, s_k = 1.0;
  double epsilon = pow (10.0, -(double)decimal_digits);
  size_t k;

  for (k = 0; ; ++k)
  {
    double term = s_k * (RAMANUJAN_SATO_A + LINEAR_COEFFICIENT_B*k);

    if (term <= epsilon)
      break;

    sum += term;

    { double signature_index = 4.0 * k,
             index_plus_1_sq = (k + 1.0) * (k + 1.0);

      double fraction = ((signature_index + 1.0) *
                         (signature_index + 2.0) *
                         (signature_index + 3.0) *
                         (signature_index + 4.0)) /
                        (index_plus_1_sq * index_plus_1_sq *
                         CONVERGENCE_BASE_SQ * CONVERGENCE_BASE_SQ);

      s_k *= fraction;
    }
  }

  return (1.0 / (sum * (2.0*sqrt(2.0) / MODULAR_DENOMINATOR)));
}
