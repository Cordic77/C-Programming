../lib/a-utf8-x86-debug/up_src_binary32_sin_sinf.c.o: \
 ../src/binary32/sin/sinf.c
