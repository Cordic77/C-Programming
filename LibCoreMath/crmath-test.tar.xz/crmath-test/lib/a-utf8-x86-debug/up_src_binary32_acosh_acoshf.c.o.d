../lib/a-utf8-x86-debug/up_src_binary32_acosh_acoshf.c.o: \
 ../src/binary32/acosh/acoshf.c
