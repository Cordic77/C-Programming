../lib/a-utf8-x64-debug/up_src_binary64_cosh_cosh.c.o: \
 ../src/binary64/cosh/cosh.c
