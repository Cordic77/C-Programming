#include <stdio.h>           /* fprintf() */
#include <ctype.h>           /* isspace() */
#include <locale.h>          /* setlocale() */
#include <uchar.h>

/* FSFʼs libunistring library: */
#include <unitypes.h>        /* ucs4_t */
#include <unictype.h>        /* uc_is_space */

/* Unicode Consortiumʼs ICU library: */
#include <unicode/uchar.h>


/* Preprocessor macros: */
#if __STDC_VERSION__ < 202901L  /*FIXME once C2y is released */
  /* Results! - The Big Array Size Survey for C. (C29 will have a countof() operator): */
  #if (!defined(__STDC_VERSION__) || __STDC_VERSION__ <= 202311L) && !defined(countof)
  #define countof(arr)  (sizeof(arr)/sizeof((arr)[0]))
  #endif
#endif


/* Program entry point: */
int main (void)
{ size_t i;
  struct {
    UChar32     code;
    char const *name;
  } unichar [] = {
      /* ASCII whitespace characters */
      {0x0009, "HT (TAB)"},
      {0x000A, "LF"},
      {0x000B, "VT"},
      {0x000C, "FF"},
      {0x000D, "CR"},
      {0x001C, "FS"},
      {0x001D, "GS"},
      {0x001E, "RS"},
      {0x001F, "US"},
      {0x0020, "SPACE"},

      /* Unicode whitespace */
      {0x0085, "NEL"},
      {0x00A0, "NO-BREAK SPACE"},
      {0x1680, "OGHAM SPACE MARK"},

      {0x2000, "EN QUAD"},
      {0x2001, "EM QUAD"},
      {0x2002, "EN SPACE"},
      {0x2003, "EM SPACE"},
      {0x2004, "THREE-PER-EM SPACE"},
      {0x2005, "FOUR-PER-EM SPACE"},
      {0x2006, "SIX-PER-EM SPACE"},
      {0x2007, "FIGURE SPACE"},
      {0x2008, "PUNCTUATION SPACE"},
      {0x2009, "THIN SPACE"},
      {0x200A, "HAIR SPACE"},

      {0x2028, "LINE SEPARATOR"},
      {0x2029, "PARAGRAPH SEPARATOR"},
      {0x202F, "NARROW NO-BREAK SPACE"},
      {0x205F, "MEDIUM MATHEMATICAL SPACE"},
      {0x3000, "IDEOGRAPHIC SPACE"},
    };

  setlocale (LC_ALL, "");

  printf("Code   Name                    isspace  uc_is_space  u_isspace\n");
  printf("--------------------------------------------------------------\n");

  for (i = 0; i < countof(unichar); i++)
  { ucs4_t ch = unichar [i].code;

    /* Note: isspace() is not defined for character codes above 0xFF! */
    int ctype_isspace  = (ch <= 0xFF)? !!isspace ((unsigned char)ch) : 0;
    int libuni_isspace = !!uc_is_space ((ucs4_t)ch);
    int icu_isspace    = !!u_isspace (ch);

    fprintf (stdout, "U+%04X  %-26s %-10d %-10d %-6d\n", ch, unichar [i].name,
             ctype_isspace, libuni_isspace, icu_isspace);
  }

  return (0);
}
