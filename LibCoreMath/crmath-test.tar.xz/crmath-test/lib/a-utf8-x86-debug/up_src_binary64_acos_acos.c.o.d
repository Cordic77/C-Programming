../lib/a-utf8-x86-debug/up_src_binary64_acos_acos.c.o: \
 ../src/binary64/acos/acos.c
