#include <limits.h>               /* LONG_MAX */
#include <iso646.h>               /* not, and, or, xor */
#include <io.h>                   /* isatty(), read(), write() */

extern long int random (void);

#define fileno _fileno
#define isatty _isatty
#define read _read
#define write _write

#define strdup _strdup

/* Visual Studio 14+ defines snprintf to _snprintf in stdio.h: */
#if _MSC_VER < 1900
  #define snprintf _snprintf
#endif
