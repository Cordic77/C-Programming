../lib/so-utf8-x64-release/up_src_binary32_sin_sinf.c.o: \
 ../src/binary32/sin/sinf.c
