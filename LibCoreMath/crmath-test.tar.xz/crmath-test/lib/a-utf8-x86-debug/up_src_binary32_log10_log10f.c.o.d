../lib/a-utf8-x86-debug/up_src_binary32_log10_log10f.c.o: \
 ../src/binary32/log10/log10f.c
