#include <stdio.h>                /* snprintf() */
#include <string.h>               /* strchr() */
#include <ctype.h>                /* isdigit() */
#include <math.h>                 /* pow() */

#include "gmp.h"                  /* GNU Multiple Precision Arithmetic Library */

#include "stdcountof.h"

/* MSVC compatibility: */
#if defined(_MSC_VER) && _MSC_VER < 1900  /* < VS2015? */
#define snprintf _snprintf
#endif


/* double values, when printed, can get quite large:

DBL_MAX = 2¹⁰²⁴ - 2¹⁰²⁴⁻⁵³, req. a total of (311+1) chars:
+17976931348623157081452742373170435679807056752584499659891747680315726078002853876058955863276687817154045895351438246423432132688946418276846754670353751698604991057655128207624549009038932894407586850845513394230458323690322294816580855933212334827479782620414472316873817718091929988125040402618412485836.00000000000000000

DBL_MIN = -2¹⁰²², req. a total of (327+1) chars:
-0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022250738585072014

   Taken together this means we may need to reserve (635+1) chars to be able
   to handle large (positive) as well as small (negative) numbers:
*/
typedef char double_string [635+1];


/* Forward declarations: */
static void
  double_to_string (double const double_val, double_string double_str);
static void
  simplify_repeating_decimals (double_string double_str, size_t nz_digit, mpz_t integral, mpz_t divisor);
static void
  divide_by_gcd (mpz_t numerator, mpz_t denominator);


/* Returns the ‘numerator’ and ‘denominator’ of a fraction that should
   result in ‘double_val’ if evaluated.
*/
int decimal_to_fraction (double const double_val, mpz_t numerator, mpz_t denominator)
{ double_string
    double_str;             /* double_val converted to a string */

  /* float → string coversion: */
  double_to_string (double_val, double_str);

  /* Is it an integral number? */
  { size_t decimal_point_index,
           fractional_digits;

    { char const *decimal_point = strchr (double_str, '.');

      if (decimal_point == NULL)  /* (Shouldn't normally happen.) */
      {
        if (mpz_set_str (numerator, double_str, 10) != 0)
          return (0);

        mpz_set_ui (denominator, 1);
        return (1);
      }

      decimal_point_index = (size_t)(decimal_point - double_str);
      fractional_digits = strlen (double_str + decimal_point_index + 1);

      memmove (double_str + decimal_point_index,
               double_str + decimal_point_index + 1,
               fractional_digits + 1);
    }

    /* Find first non-zero digit in the fractional part: */
    { size_t nz_digit = decimal_point_index;

      while (double_str [nz_digit] == '0')
        nz_digit++;

      /* Power of 10 to multiply with to get to a whole number? */
      { mpz_t
          integral,         /* double_val converted to an integral */
          divisor;          /* value (initially a power of 10) ‘double_val’ was scaled by */

        int sign = (double_str [0] == '-')? -1 : +1;

        /* Calculate the ‘denominator’ as a power of 2: */
        mpz_inits (integral, divisor, NULL);
        mpz_ui_pow_ui (divisor, 10u, (unsigned long)fractional_digits);

        if (mpz_set_str (integral, double_str, 10) != 0)
        {
          mpz_clears (integral, divisor, NULL);
          return (0);
        }
        mpz_abs (integral, integral);

        /* Test for repeating decimals at the end of the digit string: */
        simplify_repeating_decimals (double_str, nz_digit, integral, divisor);

        /* Divide ‘integral_val’ and ‘power_10’ by their GCD to reduce them to smaller numbers: */
        divide_by_gcd (integral, divisor);

        mpz_set (numerator, integral);
        if (sign < 0)
          mpz_neg (numerator, numerator);

        mpz_set (denominator, divisor);

        mpz_clears (integral, divisor, NULL);
        return (1);
      }
    }
  }
}


static void double_to_string (double const double_val, double_string double_str)
{
  /* Get string representation for given ‘double_val’: */
  #ifdef _MSC_VER  /* Doesnʼt support "%.324lf", chokes up on it: */
  snprintf (double_str, 635, "%.15lf", double_val);

  { double abs_value = double_val;
    if (abs_value < 0.0)
    {
      abs_value = -abs_value;
     *double_str++ = '-';
    }

    if (abs_value == DBL_MIN)
      strcpy (double_str, "0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000022250738585072014");
    else
    if (abs_value == DBL_MAX)
      strcpy (double_str, "17976931348623157081452742373170435679807056752584499659891747680315726078002853876058955863276687817154045895351438246423432132688946418276846754670353751698604991057655128207624549009038932894407586850845513394230458323690322294816580855933212334827479782620414472316873817718091929988125040402618412485836.00000000000000000");
  }
  #else
  snprintf (double_str, 635, "%.324lf", double_val);
  #endif

  /* Try to somewhat clean up the parsed value: */
  { char *decimal_point = strchr (double_str, '.');

    if (decimal_point)
    {
      char *last_digit = strchr (decimal_point+1, '\0') - 1;

      /* Remove trailing zeroes: */
      while (*last_digit == '0')
       *last_digit-- = '\0';

      if (*last_digit == '.')
       *last_digit = '\0';
      else
      {
        /* Remove other digits after the decimal point, leave only 17 (16+1) in total: */
        char *fractional_digits = decimal_point+1;

        while (*fractional_digits == '0')
          fractional_digits++;

        fractional_digits += 17;

        if (fractional_digits < last_digit)
         *fractional_digits++ = '\0';
      }
    }
  }
}


/* Function capable of detecting repeating decimals with a period of up to 6.

  The function assumes that a periodicity exists when a sequence of digits is
  repeated twice. As such, the following implementation is not a reliable one
  but more of a heuristic.
*/
#define MAX_REPEATING_DECIMAL_PERIOD  6   /* check for repeating decimals of a period up to 6 digits */
#define STRIP_DIGITS_PLACES           1   /* strip off digits at the end of ‘double_str’ */
#define STRIP_DIGITS_DIVISOR         10   /* … by dividing the given ‘integral’ value */


static void simplify_repeating_decimals (double_string double_str, size_t nz_digit, mpz_t integral, mpz_t divisor)
{ size_t displacement, i;

  size_t digit_string_len = strlen (double_str + nz_digit);

  digit_string_len -= STRIP_DIGITS_PLACES;                /* We require ‘2*MAX_PERIOD + STRIP_DIGITS_PLACES’ digits… assuming the last */
  if (digit_string_len < 2*MAX_REPEATING_DECIMAL_PERIOD)  /* digit in the decimal expansion may be rounded (and thus not a match) */
    return;

  for (displacement = 1; displacement <= MAX_REPEATING_DECIMAL_PERIOD; displacement++)
  {
    size_t last_index = nz_digit + digit_string_len - STRIP_DIGITS_PLACES,
           must_match = 2 * displacement;

    if (must_match < MAX_REPEATING_DECIMAL_PERIOD)
      must_match = (3 * MAX_REPEATING_DECIMAL_PERIOD) / 2;

    for (i = last_index - displacement; i >= nz_digit; i--)
    {
      if (double_str [i + displacement] != double_str [i])
        break;
    }

    if (last_index - i >= must_match)
    { mpz_t strip_ulp, power_10, repeating;
      mpz_inits (strip_ulp, power_10, repeating, NULL);

      mpz_fdiv_q_ui (strip_ulp, integral, STRIP_DIGITS_DIVISOR);  /* strip_ulp = integral / 10; */
      mpz_ui_pow_ui (power_10, 10u, (unsigned long)displacement); /* power_10 = 10^displacement */

      mpz_mod (repeating, strip_ulp, power_10);                   /* repeating = strip_ulp % power_10 */

	    { mpz_t append_repeat_decimal;
	      mpz_init (append_repeat_decimal);

        mpz_mul (append_repeat_decimal, strip_ulp, power_10);     /* *integral = (numerator - strip_ulp) * STRIP_DIGITS_DIVISOR; */
        mpz_add (append_repeat_decimal, append_repeat_decimal, repeating);
        mpz_sub (append_repeat_decimal, append_repeat_decimal, strip_ulp);
        mpz_mul_ui (integral, append_repeat_decimal, STRIP_DIGITS_DIVISOR);

        mpz_clear (append_repeat_decimal);
      }

	    { mpz_t power_10_minus_1;
        mpz_init (power_10_minus_1);

        mpz_sub_ui (power_10_minus_1, power_10, 1u);
        mpz_mul (divisor, divisor, power_10_minus_1);             /* divisor *= (power_10 - 1) */

        mpz_clear (power_10_minus_1);
      }

      mpz_clears (strip_ulp, power_10, repeating, NULL);
    }
  }
}


/* Simplify the given fraction by dividing numerator and denominator by gcd */
static void divide_by_gcd(mpz_t numerator, mpz_t denominator)
{
  mpz_t gcd;

  mpz_init(gcd);
  mpz_gcd(gcd, numerator, denominator);

  if (mpz_cmp_ui(gcd, 0) != 0)
  {
    mpz_divexact(numerator, numerator, gcd);
    mpz_divexact(denominator, denominator, gcd);
  }

  /* Keep denominator positive */
  if (mpz_sgn(denominator) < 0)
  {
    mpz_neg(numerator, numerator);
    mpz_neg(denominator, denominator);
  }

  mpz_clear(gcd);
}
