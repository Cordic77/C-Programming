#pragma once
#ifndef SC_COUNTOF_H_
#define SC_COUNTOF_H_

#include "2029/stdcountof.h"

#endif /* SC_COUNTOF_H_ */
