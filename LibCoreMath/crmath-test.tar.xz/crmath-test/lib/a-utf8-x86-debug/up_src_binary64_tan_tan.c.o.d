../lib/a-utf8-x86-debug/up_src_binary64_tan_tan.c.o: \
 ../src/binary64/tan/tan.c
