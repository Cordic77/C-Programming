../lib/a-utf8-x86-debug/up_src_binary32_sinpi_sinpif.c.o: \
 ../src/binary32/sinpi/sinpif.c
