../lib/a-utf8-x86-debug/up_src_binary64_log_log.c.o: \
 ../src/binary64/log/log.c ../src/binary64/log/dint.h
../src/binary64/log/dint.h:
