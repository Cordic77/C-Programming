../lib/a-utf8-x86-release/up_src_binary32_cosh_coshf.c.o: \
 ../src/binary32/cosh/coshf.c
