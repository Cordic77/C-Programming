../lib/so-utf8-x64-release/up_src_binary64_rsqrt_rsqrt.c.o: \
 ../src/binary64/rsqrt/rsqrt.c
