../lib/a-utf8-x64-release/up_src_binary32_tanpi_tanpif.c.o: \
 ../src/binary32/tanpi/tanpif.c
