../lib/so-utf8-x64-debug/up_src_binary64_lgamma_lgamma.c.o: \
 ../src/binary64/lgamma/lgamma.c
