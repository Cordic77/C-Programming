#define WinEditLine_VERSION_MAJOR 2
#define WinEditLine_VERSION_MINOR 1
