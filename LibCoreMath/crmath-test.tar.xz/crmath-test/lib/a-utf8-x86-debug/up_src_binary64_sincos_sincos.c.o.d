../lib/a-utf8-x86-debug/up_src_binary64_sincos_sincos.c.o: \
 ../src/binary64/sincos/sincos.c
