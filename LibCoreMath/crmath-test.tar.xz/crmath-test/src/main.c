#define _GNU_SOURCE 1

#include <stdio.h>                 /* fprintf(), stdout, stderr */
#include <stdlib.h>                /* malloc(), free(), EXIT_SUCCESS */

#include <math.h>                  /* libc math functions */
#include <float.h>                 /* FLT_EPSILON, DBL_EPSILON */

#include "core-math.h"             /* The CORE-MATH project */


/* C23 standards support? */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L /* ISO/IEC 9899:2023 (or later)? */
  #define ISO_C23 1
#endif

/* Inexact floating-point comparision macros: */
#define FLT_EQ_EPS(a, b) ((fpclassify(a) == FP_INFINITE && fpclassify(b) == FP_INFINITE) || (a - b) < FLT_EPSILON)
#define DBL_EQ_EPS(a, b) ((fpclassify(a) == FP_INFINITE && fpclassify(b) == FP_INFINITE) || (a - b) < DBL_EPSILON)


/* Function declarations: */
static void crmath_float (void);
static void crmath_double (void);


/* Global constants: */
char const *TEST_PASS = "\033[92mpass\033[0m";
char const *TEST_FAIL = "\033[91mfail\033[0m";


/* Program entry point: */
int main (void)
{
  crmath_float ();
  fputc ('\n', stdout);

  crmath_double ();
  fputc ('\n', stdout);

  return (EXIT_SUCCESS);
}


/* Core math ‘float’ tests: */
static void crmath_float (void)
{ float x = 1.0f;
  float libc, crmt;

  fprintf (stdout, "\033[93mCORE-MATH ‘float’ functions:\033[0m\n\n");

  fprintf (stdout, "(hyperbolic) arccosine:\n");
  {
    libc = acosf (x);
    crmt = cr_acosf (x);
    fprintf (stdout, "   acosf(x) %.7f ≅ %.7f cr_acosf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = acoshf (x);
    crmt = cr_acoshf (x);
    fprintf (stdout, "  acoshf(x) %.7f ≅ %.7f cr_acoshf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = acosf (x) / (float)M_PI;  /* acospif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_acospif (x);
    fprintf (stdout, " acosf(x)÷π %.7f ≅ %.7f cr_acospif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) arcsine:\n");
  {
    libc = asinf (x);
    crmt = cr_asinf (x);
    fprintf (stdout, "   asinf(x) %.7f ≅ %.7f cr_asinf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = asinhf (x);
    crmt = cr_asinhf (x);
    fprintf (stdout, "  asinhf(x) %.7f ≅ %.7f cr_asinhf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = asinf (x) / (float)M_PI;  /* asinpif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_asinpif (x);
    fprintf (stdout, " asinf(x)÷π %.7f ≅ %.7f cr_asinpif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) arctangent:\n");
  {
    libc = atan2f (M_SQRT2, M_SQRT2);
    crmt = cr_atan2f (M_SQRT2, M_SQRT2);
    fprintf (stdout, " atan2f(y, x)   %.7f ≅ %.7f cr_atan2f(y, x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atan2f (M_SQRT2, M_SQRT2) / (float)M_PI;  /* atan2pif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_atan2pif (M_SQRT2, M_SQRT2);
    fprintf (stdout, " atan2f(y, x)÷π %.7f ≅ %.7f cr_atan2pif(y, x): %s\n\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atanf (x);
    crmt = cr_atanf (x);
    fprintf (stdout, "   atanf(x) %.7f ≅ %.7f cr_atanf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atanhf (x);
    crmt = cr_atanhf (x);
    fprintf (stdout, "  atanhf(x) %.7f ≅ %.7f cr_atanhf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atanf (x) / (float)M_PI;  /* atanpif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_atanpif (x);
    fprintf (stdout, " atanf(x)÷π %.7f ≅ %.7f cr_atanpif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\ncube root:\n");
  {
    libc = cbrtf (x);
    crmt = cr_cbrtf (x);
    fprintf (stdout, "   cbrtf(x) %.7f ≅ %.7f cr_cbrtf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) cosine:\n");
  {
    libc = cosf (x);
    crmt = cr_cosf (x);
    fprintf (stdout, "    cosf(x) %.7f ≅ %.7f cr_cosf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = coshf (x);
    crmt = cr_coshf (x);
    fprintf (stdout, "   coshf(x) %.7f ≅ %.7f cr_coshf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = cosf (x * (float)M_PI);
  /*#endif*/
    crmt = cr_cospif (x);
    fprintf (stdout, "  cosf(x*π) %.7f ≅ %.7f cr_cospif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) sine:\n");
  {
    libc = sinf (x);
    crmt = cr_sinf (x);
    fprintf (stdout, "    sinf(x) %.7f ≅ %.7f cr_sinf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = sinhf (x);
    crmt = cr_sinhf (x);
    fprintf (stdout, "   sinhf(x) %.7f ≅ %.7f cr_sinhf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = sinf (x * (float)M_PI);
  /*#endif*/
    crmt = cr_sinpif (x);
    fprintf (stdout, "  sinf(x*π) %.7f ≅ %.7f cr_sinpif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\ncalculate sin and cos simultaneously:\n");
  { float libc_sin, libc_cos;
    float crmt_sin, crmt_cos;

    #if defined(_GNU_SOURCE)
    sincosf (x, &libc_sin, &libc_cos);
    #else
    libc_sin = sinf (x);
    libc_cos = cosf (x);
    #endif
    cr_sincosf (x, &crmt_sin, &crmt_cos);
    fprintf (stdout, "sin %.7f, cos %.7f ≅ cr_sincosf %.7f, %.7f: %s\n",
                     libc_sin, libc_cos, crmt_sin, crmt_cos,
                     (FLT_EQ_EPS(libc_sin, crmt_sin) && FLT_EQ_EPS(libc_cos, crmt_cos)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) tangent:\n");
  {
    libc = tanf (x);
    crmt = cr_tanf (x);
    fprintf (stdout, "    tanf(x) %.7f ≅ %.7f cr_tanf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = tanhf (x);
    crmt = cr_tanhf (x);
    fprintf (stdout, "   tanhf(x) %.7f ≅ %.7f cr_tanhf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = tanf (x * (float)M_PI);
  /*#endif*/
    crmt = cr_tanpif (x);
    fprintf (stdout, "  tanf(x*π) %.7f ≅ %.7f cr_tanpif(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(complimentary) Gauss error function:\n");
  {
    libc = erff (x);
    crmt = cr_erff (x);
    fprintf (stdout, "    erff(x) %.7f ≅ %.7f cr_erff(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = erfcf (x);
    crmt = cr_erfcf (x);
    fprintf (stdout, "   erfcf(x) %.7f ≅ %.7f cr_erfcf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-10 exponential function:\n");
  {
    #if defined(_GNU_SOURCE)
    libc = exp10f (x);
    #else
    libc = powf (10.f, x);
    #endif
    crmt = cr_exp10f (x);
    fprintf (stdout, "  exp10f(x) %.7f ≅ %.7f cr_exp10f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = powf (10.f, x) - 1.f;  /* exp10m1() is not in standard C */
    crmt = cr_exp10m1f (x);
    fprintf (stdout, "exp10f(x)-1 %.7f ≅ %.7f cr_exp10m1f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-2 exponential function:\n");
  {
    libc = exp2f (x);
    crmt = cr_exp2f (x);
    fprintf (stdout, "   exp2f(x) %.7f ≅ %.7f cr_exp2f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = exp2f (x) - 1.f;  /* exp10m1() is not in standard C */
    crmt = cr_exp2m1f (x);
    fprintf (stdout, " exp2f(x)-1 %.7f ≅ %.7f cr_exp2m1f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-e exponential function:\n");
  {
    libc = expf (x);
    crmt = cr_expf (x);
    fprintf (stdout, "    expf(x) %.7f ≅ %.7f cr_expf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = expm1f (x);
    crmt = cr_expm1f (x);
    fprintf (stdout, "  expm1f(x) %.7f ≅ %.7f cr_expm1f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(Euclidean) distance function:\n");
  {
    libc = hypotf (3.f, 4.f);
    crmt = cr_hypotf (3.f, 4.f);
    fprintf (stdout, "  hypotf(3.f, 4.f) %.7f ≅ %.7f cr_hypotf(3.f, 4.f): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nlog/true gamma function:\n");
  {
    libc = lgammaf (x);
    crmt = cr_lgammaf (x);
    fprintf (stdout, " lgammaf(x) %.7f ≅ %.7f cr_lgammaf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = tgammaf (x);
    crmt = cr_tgammaf (x);
    fprintf (stdout, " tgammaf(x) %.7f ≅ %.7f cr_tgammaf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-10 logarithmic function:\n");
  {
    libc = log10f (x);
    crmt = cr_log10f (x);
    fprintf (stdout, "  log10f(x) %.7f ≅ %.7f cr_log10f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = log10f (x + 1.f);  /* log10p1f() is not in standard C */
    crmt = cr_log10p1f (x);
    fprintf (stdout, "log10f(x+1) %.7f ≅ %.7f cr_log10p1f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nlog of 1 plus argument:\n");
  {
    libc = log1pf (x);
    crmt = cr_log1pf (x);
    fprintf (stdout, "  log1pf(x) %.7f ≅ %.7f cr_log1pf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-2 logarithmic function:\n");
  {
    libc = log2f (x);
    crmt = cr_log2f (x);
    fprintf (stdout, "   log2f(x) %.7f ≅ %.7f cr_log2f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = log2f (x + 1.f);  /* log2p1f() is not in standard C */
    crmt = cr_log2p1f (x);
    fprintf (stdout, " log2f(x+1) %.7f ≅ %.7f cr_log2p1f(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nnatural logarithmic/power function:\n");
  {
    libc = logf (x);
    crmt = cr_logf (x);
    fprintf (stdout, "    logf(x) %.7f ≅ %.7f cr_logf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = powf (x / 3.f, 2.);
    crmt = cr_powf (x / 3.f, 2.);
    fprintf (stdout, "powf(⅓x, 2) %.7f ≅ %.7f cr_powf(⅓x, 2): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nreciprocal square root:\n");
  {
  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = 1.f / sqrtf (x);
  /*#endif*/
    crmt = cr_rsqrtf (x);
    fprintf (stdout, " 1÷sqrtf(x) %.7f ≅ %.7f cr_rsqrtf(x): %s\n", libc, crmt, (FLT_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }
}


static void crmath_double (void)
{ double x = 1.0;
  double libc, crmt;

  fprintf (stdout, "\033[93mCORE-MATH ‘double’ functions:\033[0m\n\n");

  fprintf (stdout, "(hyperbolic) arccosine:\n");
  {
    libc = acos (x);
    crmt = cr_acos (x);
    fprintf (stdout, "    acos(x) %.15lf ≅ %.15lf cr_acos(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = acosh (x);
    crmt = cr_acosh (x);
    fprintf (stdout, "   acosh(x) %.15lf ≅ %.15lf cr_acosh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = acos (x) / M_PI;  /* acospif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_acospi (x);
    fprintf (stdout, "  acos(x)÷π %.15lf ≅ %.15lf cr_acospi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) arcsine:\n");
  {
    libc = asin (x);
    crmt = cr_asin (x);
    fprintf (stdout, "    asin(x) %.15lf ≅ %.15lf cr_asin(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = asinh (x);
    crmt = cr_asinh (x);
    fprintf (stdout, "   asinh(x) %.15lf ≅ %.15lf cr_asinh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = asin (x) / M_PI;  /* asinpi() is not in the C standard, FP Ext 4 TS */
    crmt = cr_asinpi (x);
    fprintf (stdout, "  asin(x)÷π %.15lf ≅ %.15lf cr_asinpi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) arctangent:\n");
  {
    libc = atan2 (M_SQRT2, M_SQRT2);
    crmt = cr_atan2 (M_SQRT2, M_SQRT2);
    fprintf (stdout, "   atan2(y, x) %.15lf ≅ %.15lf cr_atan2(y, x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atan2 (M_SQRT2, M_SQRT2) / M_PI;  /* atan2pif() is not in the C standard, FP Ext 4 TS */
    crmt = cr_atan2pi (M_SQRT2, M_SQRT2);
    fprintf (stdout, " atan2(y, x)÷π %.15lf ≅ %.15lf cr_atan2pi(y, x): %s\n\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atan (x);
    crmt = cr_atan (x);
    fprintf (stdout, "    atan(x) %.15lf ≅ %.15lf cr_atan(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atanh (x);
    crmt = cr_atanh (x);
    fprintf (stdout, "   atanh(x) %.15lf ≅ %.15lf cr_atanh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = atan (x) / M_PI;  /* atanpi() is not in the C standard, FP Ext 4 TS */
    crmt = cr_atanpi (x);
    fprintf (stdout, "  atan(x)÷π %.15lf ≅ %.15lf cr_atanpi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\ncube root:\n");
  {
    libc = cbrt (x);
    crmt = cr_cbrt (x);
    fprintf (stdout, "    cbrt(x) %.15lf ≅ %.15lf cr_cbrt(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) cosine:\n");
  {
    libc = cos (x);
    crmt = cr_cos (x);
    fprintf (stdout, "     cos(x) %.15lf ≅ %.15lf cr_cos(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = cosh (x);
    crmt = cr_cosh (x);
    fprintf (stdout, "    cosh(x) %.15lf ≅ %.15lf cr_cosh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = cos (x * M_PI);
  /*#endif*/
    crmt = cr_cospi (x);
    fprintf (stdout, "  cosf(x*π) %.15lf ≅ %.15lf cr_cospi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) sine:\n");
  {
    libc = sin (x);
    crmt = cr_sin (x);
    fprintf (stdout, "     sin(x) %.15lf ≅ %.15lf cr_sin(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = sinh (x);
    crmt = cr_sinh (x);
    fprintf (stdout, "    sinh(x) %.15lf ≅ %.15lf cr_sinh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = sin (x * M_PI);
  /*#endif*/
    crmt = cr_sinpi (x);
    fprintf (stdout, "  sinf(x*π) %.15lf ≅ %.15lf cr_sinpi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\ncalculate sin and cos simultaneously:\n");
  { double libc_sin, libc_cos;
    double crmt_sin, crmt_cos;

    #if defined(_GNU_SOURCE)
    sincos (x, &libc_sin, &libc_cos);
    #else
    libc_sin = sin (x);
    libc_cos = cos (x);
    #endif
    cr_sincos (x, &crmt_sin, &crmt_cos);
    fprintf (stdout, "sin %.15lf, cos %.15lf ≅ cr_sincosf %.15lf, %.15lf: %s\n",
                     libc_sin, libc_cos, crmt_sin, crmt_cos,
                     (DBL_EQ_EPS(libc_sin, crmt_sin) && DBL_EQ_EPS(libc_cos, crmt_cos)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(hyperbolic) tangent:\n");
  {
    libc = tan (x);
    crmt = cr_tan (x);
    fprintf (stdout, "     tan(x) %.15lf ≅ %.15lf cr_tan(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = tanh (x);
    crmt = cr_tanh (x);
    fprintf (stdout, "    tanh(x) %.15lf ≅ %.15lf cr_tanh(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = tan (x * M_PI);
  /*#endif*/
    crmt = cr_tanpi (x);
    fprintf (stdout, "   tan(x*π) %.15lf ≅ %.15lf cr_tanpi(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(complimentary) Gauss error function:\n");
  {
    libc = erf (x);
    crmt = cr_erf (x);
    fprintf (stdout, "     erf(x) %.15lf ≅ %.15lf cr_erf(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = erfc (x);
    crmt = cr_erfc (x);
    fprintf (stdout, "    erfc(x) %.15lf ≅ %.15lf cr_erfc(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-10 exponential function:\n");
  {
    #if defined(_GNU_SOURCE)
    libc = exp10 (x);
    #else
    libc = pow (10., x);
    #endif
    crmt = cr_exp10 (x);
    fprintf (stdout, "   exp10(x) %.15lf ≅ %.15lf cr_exp10(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = pow (10., x) - 1.;  /* exp10m1() is not in standard C */
    crmt = cr_exp10m1 (x);
    fprintf (stdout, " exp10(x)-1 %.15lf ≅ %.15lf cr_exp10m1(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-2 exponential function:\n");
  {
    libc = exp2 (x);
    crmt = cr_exp2 (x);
    fprintf (stdout, "    exp2(x) %.15lf ≅ %.15lf cr_exp2(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = exp2 (x) - 1.;  /* exp10m1() is not in standard C */
    crmt = cr_exp2m1 (x);
    fprintf (stdout, "  exp2(x)-1 %.15lf ≅ %.15lf cr_exp2m1(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-e exponential function:\n");
  {
    libc = exp (x);
    crmt = cr_exp (x);
    fprintf (stdout, "     exp(x) %.15lf ≅ %.15lf cr_exp(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = expm1 (x);
    crmt = cr_expm1 (x);
    fprintf (stdout, "   expm1(x) %.15lf ≅ %.15lf cr_expm1(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\n(Euclidean) distance function:\n");
  {
    libc = hypot (3., 4.);
    crmt = cr_hypot (3., 4.);
    fprintf (stdout, " hypot(3., 4.) %.15lf ≅ %.15lf cr_hypot(3., 4.): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nlog/true gamma function:\n");
  {
    libc = lgamma (x);
    crmt = cr_lgamma (x);
    fprintf (stdout, "  lgamma(x) %.15lf ≅ %.15lf cr_lgamma(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = tgamma (x);
    crmt = cr_tgamma (x);
    fprintf (stdout, "  tgamma(x) %.15lf ≅ %.15lf cr_tgamma(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-10 logarithmic function:\n");
  {
    libc = log10 (x);
    crmt = cr_log10 (x);
    fprintf (stdout, "   log10(x) %.15lf ≅ %.15lf cr_log10(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = log10 (x + 1.);  /* log10p1() is not in standard C */
    crmt = cr_log10p1 (x);
    fprintf (stdout, "log10f(x+1) %.15lf ≅ %.15lf cr_log10p1(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nlog of 1 plus argument:\n");
  {
    libc = log1p (x);
    crmt = cr_log1p (x);
    fprintf (stdout, "   log1p(x) %.15lf ≅ %.15lf cr_log1p(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nbase-2 logarithmic function:\n");
  {
    libc = log2 (x);
    crmt = cr_log2 (x);
    fprintf (stdout, "    log2(x) %.15lf ≅ %.15lf cr_log2(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));

    libc = log2 (x + 1.);  /* log2p1() is not in standard C */
    crmt = cr_log2p1 (x);
    fprintf (stdout, " log2f(x+1) %.15lf ≅ %.15lf cr_log2p1(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nnatural logarithmic function:\n");
  {
    libc = log (x);
    crmt = cr_log (x);
    fprintf (stdout, "     log(x) %.15lf ≅ %.15lf cr_log(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\npower function:\n");
  {
    libc = pow (x / 3., 2.);
    crmt = cr_pow (x / 3., 2.);
    fprintf (stdout, " pow(⅓x, 2) %.15lf ≅ %.15lf cr_pow(⅓x, 2): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }

  fprintf (stdout, "\nreciprocal square root:\n");
  {
  /*#if ISO_C23*/  /* (In principle supported from C23 onwards.) */
    libc = 1. / sqrt (x);
  /*#endif*/
    crmt = cr_rsqrt (x);
    fprintf (stdout, "  1÷sqrt(x) %lf ≅ %lf cr_rsqrt(x): %s\n", libc, crmt, (DBL_EQ_EPS(libc, crmt)? TEST_PASS : TEST_FAIL));
  }
}
