../lib/a-utf8-x86-release/up_src_binary64_log10p1_log10p1.c.o: \
 ../src/binary64/log10p1/log10p1.c ../src/binary64/log10p1/dint.h
../src/binary64/log10p1/dint.h:
