#pragma once
#ifndef SC_INTTYPES_H_
#define SC_INTTYPES_H_

#include "1999/inttypes.h"

#endif /* SC_INTTYPES_H_ */
