../lib/so-utf8-x64-release/up_src_binary64_tan_tan.c.o: \
 ../src/binary64/tan/tan.c
