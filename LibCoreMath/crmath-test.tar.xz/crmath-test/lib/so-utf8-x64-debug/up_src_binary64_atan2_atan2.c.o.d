../lib/so-utf8-x64-debug/up_src_binary64_atan2_atan2.c.o: \
 ../src/binary64/atan2/atan2.c ../src/binary64/atan2/tint.h
../src/binary64/atan2/tint.h:
