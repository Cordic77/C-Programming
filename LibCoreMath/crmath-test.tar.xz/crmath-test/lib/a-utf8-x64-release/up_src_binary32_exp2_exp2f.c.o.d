../lib/a-utf8-x64-release/up_src_binary32_exp2_exp2f.c.o: \
 ../src/binary32/exp2/exp2f.c
