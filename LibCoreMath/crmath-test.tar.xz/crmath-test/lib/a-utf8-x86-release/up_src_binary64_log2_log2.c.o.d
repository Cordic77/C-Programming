../lib/a-utf8-x86-release/up_src_binary64_log2_log2.c.o: \
 ../src/binary64/log2/log2.c
