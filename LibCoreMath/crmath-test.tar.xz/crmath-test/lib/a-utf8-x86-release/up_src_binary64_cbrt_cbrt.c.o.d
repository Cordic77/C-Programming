../lib/a-utf8-x86-release/up_src_binary64_cbrt_cbrt.c.o: \
 ../src/binary64/cbrt/cbrt.c
