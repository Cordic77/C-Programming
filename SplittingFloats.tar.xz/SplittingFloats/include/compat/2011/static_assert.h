#pragma once
#ifndef _C11_STATIC_ASSERT_H_ /* [ */
#define _C11_STATIC_ASSERT_H_

/* C.f. Compile time assertions in C, https://www.pixelbeat.org/programming/gcc/static_assert.html */

#if ((defined(_MSC_VER) && _MSC_VER >= 1600) || (defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 6)))) \
    && defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L
/*#error "<static_assert.h> unnecessary as _Static_assert works as-is. */
  #if !defined(static_assert)
  #define static_assert _Static_assert
  #endif

#else

#if !defined(static_assert)  /* … if not already defined! */
  /* C11 adds a new ‘_Static_assert’ keyword: */
  #if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L  /* >= C11 support? */
    #define static_assert _Static_assert
  #endif

  /* Otherwise, rely on some preprocessor magic to provide a custom version: */
  #if !defined(static_assert)
    #define STATIC_ASSERT_CONCAT_HELPER(a, b) a##b
    #define STATIC_ASSERT_CONCAT(a, b) STATIC_ASSERT_CONCAT_HELPER(a, b)

    #define static_assert(expression, message) \
      typedef char STATIC_ASSERT_CONCAT(static_assert_, __LINE__) [(expression)? 1 : -1]
  #endif

  /* Still not defined? Give up. */
  #if !defined(static_assert)
    #error "Unsupported compiler detected, please adjust the definitions in static_assert.h!"
  #endif
#endif

#endif

#endif /* _C11_STATIC_ASSERT_H_ ] */
