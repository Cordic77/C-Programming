../lib/a-utf8-x64-release/up_src_binary32_hypot_hypotf.c.o: \
 ../src/binary32/hypot/hypotf.c
