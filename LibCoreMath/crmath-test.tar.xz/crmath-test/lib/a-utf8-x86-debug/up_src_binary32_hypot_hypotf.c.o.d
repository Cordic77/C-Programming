../lib/a-utf8-x86-debug/up_src_binary32_hypot_hypotf.c.o: \
 ../src/binary32/hypot/hypotf.c
