../lib/so-utf8-x64-release/up_src_binary32_pow_powf.c.o: \
 ../src/binary32/pow/powf.c
