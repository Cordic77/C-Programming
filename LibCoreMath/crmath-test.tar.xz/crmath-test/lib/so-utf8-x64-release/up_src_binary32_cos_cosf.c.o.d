../lib/so-utf8-x64-release/up_src_binary32_cos_cosf.c.o: \
 ../src/binary32/cos/cosf.c
