../lib/so-utf8-x64-debug/up_src_binary64_acospi_acospi.c.o: \
 ../src/binary64/acospi/acospi.c
