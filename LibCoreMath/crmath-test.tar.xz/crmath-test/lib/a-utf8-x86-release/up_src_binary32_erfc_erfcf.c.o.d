../lib/a-utf8-x86-release/up_src_binary32_erfc_erfcf.c.o: \
 ../src/binary32/erfc/erfcf.c
