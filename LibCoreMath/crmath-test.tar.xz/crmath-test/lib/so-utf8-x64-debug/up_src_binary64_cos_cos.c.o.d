../lib/so-utf8-x64-debug/up_src_binary64_cos_cos.c.o: \
 ../src/binary64/cos/cos.c
