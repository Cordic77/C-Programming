/* C89 headers: */
#include <stdio.h>
#include <stdlib.h>               /* EXIT_SUCCESS, EXIT_FAILURE */

/* Compiler-specific: */
#if defined(_MSC_VER)
  #include <intrin.h>
#endif

/* Compatibility macros: */
#if !defined(BUILD_ARCH_BITS)
  #if defined(_WIN32)
    #if defined(_WIN64) || defined(_M_X64) || defined(_M_AMD64)
      #define BUILD_ARCH_BITS  64
      typedef unsigned long long address_t;
    #else
      #define BUILD_ARCH_BITS  32
      typedef unsigned long address_t;
    #endif

  #elif defined(__linux__) || defined(__MACH__)
    #if defined(__LP64__) || defined(__x86_64__) || defined(__amd64__)
      #define BUILD_ARCH_BITS  64
      typedef unsigned long long address_t;
    #else
      #define BUILD_ARCH_BITS  32
      typedef unsigned long address_t;
    #endif

  #else
    #error "Only x86/x64 is supported."
  #endif
#endif

/* "This attribute, attached to a function, means that the function is meant
    to be possibly unused. GCC will not produce a warning for this function."*/
#ifndef MAYBE_UNUSED
  #if defined(__GNUC__)
    #define MAYBE_UNUSED __attribute__((unused))
  #else
    #define MAYBE_UNUSED
  #endif
#endif

/* Helper macro for thread-local variables: */
#ifndef thread_local
  #if __STDC_VERSION__ >= 201112 && !defined __STDC_NO_THREADS__
    #define thread_local _Thread_local
  #elif defined(_MSC_VER)
    #define thread_local __declspec(thread)
  #elif defined(__GNUC__)
    #define thread_local __thread
  #else
    #error "thread_local: unrecognized compiler"
  #endif
#endif


/* Function declarations: */
void count_recursively (unsigned long long number) MAYBE_UNUSED;
static void count_via_return (unsigned long long number) MAYBE_UNUSED;


/* Program entry point: */
int main (void)
{ unsigned long long count;

  fprintf (stdout, "Loop count = ");
  /* GCC Bug 66425: (void) cast doesn't suppress __attribute__((warn_unused_result))
           https://gcc.gnu.org/bugzilla/show_bug.cgi?id=66425#c34 */
  (void)!fscanf (stdin, "%llu", &count);

  //count_recursively (count);
  count_via_return (count);

  return (EXIT_SUCCESS);
}


/* Simple recursive function to count up from 1 to a given number */
void count_recursively (unsigned long long number)
{
  if (number > 1)
    count_recursively (number-1);

  fprintf (stdout, "%llu\n", number);
  fflush (stdout);
}

/* Manipulates the return address on the stack to simulate iteration via the return statement */
#if defined(_MSC_VER)
#define STACK_GET_RETURN_ADDRESS()  \
            *(address_t *)_AddressOfReturnAddress ()
#else
#define STACK_GET_RETURN_ADDRESS()  \
            *(address_t *)((char *)__builtin_frame_address(0)+sizeof(void *))
#endif
#define STACK_SET_RETURN_ADDRESS(new_return_address)  \
            STACK_GET_RETURN_ADDRESS() = (address_t)new_return_address;

static thread_local address_t loop_start_addr;

static void store_address_of_next_statement (address_t *store_memory_address)
{
  *store_memory_address = STACK_GET_RETURN_ADDRESS ()
                          #if defined(_DEBUG) && BUILD_ARCH_BITS == 32
                          + 3  /* the ADD ESP,4/8 after RET is 3 bytes long */
                          #endif
                          ;
}

#if defined(__GNUC__)
#pragma GCC push_options
#pragma GCC optimize ("O0")
#endif

static void return_to_loop_start_addr (void)
{
  STACK_SET_RETURN_ADDRESS (loop_start_addr);
  return;  /* Jump to ‘loop_start_addr’ :-) */
}

#if defined(_MSC_VER) && defined(NDEBUG)
/* Note: with optimizations enabled, MSVC optimizes `call return_to_loop_start_addr`
         to `jmp return_to_loop_start_addr`. Something we do not want here. */
#pragma optimize ("", off)
#endif

static void count_via_return (unsigned long long number)
{ static thread_local unsigned long long current_counter = 1;

  store_address_of_next_statement (&loop_start_addr);
/*loop_start:*/
  fprintf (stdout, "%llu\n", current_counter);
  current_counter++;

  if (current_counter > number)
  {
    current_counter = 1;
    return;  /* “normal” return to original caller. */
  }

  return_to_loop_start_addr ();  /* Proceed to next iteration of this “loop” */
}

#if defined(_MSC_VER) && defined(NDEBUG)
#pragma optimize ("", on)
#else
#pragma GCC pop_options
#endif
