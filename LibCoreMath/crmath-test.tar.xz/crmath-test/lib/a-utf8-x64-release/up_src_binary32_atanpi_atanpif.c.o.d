../lib/a-utf8-x64-release/up_src_binary32_atanpi_atanpif.c.o: \
 ../src/binary32/atanpi/atanpif.c
