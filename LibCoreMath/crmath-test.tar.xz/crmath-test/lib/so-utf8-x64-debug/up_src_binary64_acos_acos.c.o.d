../lib/so-utf8-x64-debug/up_src_binary64_acos_acos.c.o: \
 ../src/binary64/acos/acos.c
