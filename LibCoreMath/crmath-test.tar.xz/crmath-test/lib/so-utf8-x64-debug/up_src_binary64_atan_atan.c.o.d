../lib/so-utf8-x64-debug/up_src_binary64_atan_atan.c.o: \
 ../src/binary64/atan/atan.c
