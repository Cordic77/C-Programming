../lib/so-utf8-x64-debug/up_src_binary64_exp2m1_exp2m1.c.o: \
 ../src/binary64/exp2m1/exp2m1.c
