../lib/so-utf8-x64-release/up_src_binary32_tanh_tanhf.c.o: \
 ../src/binary32/tanh/tanhf.c
