/* C89 headers: */
#if defined(_MSC_VER)
  #define _USE_MATH_DEFINES
#else
  #define _DEFAULT_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>               /* EXIT_SUCCESS, EXIT_FAILURE */
#include <string.h>               /* strlen() */
#include <ctype.h>                /* isspace() */
#include <math.h>                 /* INFINITY, NAN */

/* Assertions: */
#if _DEBUG
  #include <assert.h>             /* assert() macro */
#else
  #undef NDEBUG
  #include <assert.h>             /* (check even in release builds.) */
  #define NDEBUG
#endif

/* C95 headers: */
#include <iso646.h>               /* not, and, or, xor */

/* C99 headers: */
#include <stdbool.h>              /* bool type, false, true */
#include <inttypes.h>             /* PRIu32 */
#include <stdint.h>               /* (u)int32_t */

/* C11 headers: */
#include "static_assert.h"

/* C29 headers: */
#include "stdcountof.h"


/* Compatibility: */
#if defined(_MSC_VER)
  #define strcasecmp _stricmp

  #if _MSC_VER < 1800  /* Visual Studio 2012 (or earlier)? */
    #define isnan _isnan
  #endif
  #if _MSC_VER < 1900  /* Visual Studio 2013 (or earlier)? */
    #define snprintf _snprintf
  #endif

  #ifndef _SSIZE_T_DEFINED
    #include <BaseTsd.h>          /* SSIZE_T */
    #undef ssize_t
    typedef SSIZE_T ssize_t;
    #define _SSIZE_T_DEFINED
  #endif

  /* Endianness: */
  #if !defined(__BYTE_ORDER__) && !defined(__clang__)  /* (clang-cl recognizes these macros.) */
    #define __ORDER_LITTLE_ENDIAN__ 1234
    #define __ORDER_BIG_ENDIAN__    4321
    #define __BYTE_ORDER__          __ORDER_LITTLE_ENDIAN__
  #endif
#else
  #include <strings.h>            /* strcasecmp() */
  #include <sys/types.h>          /* ssize_t */
#endif


/* Structures: */
typedef union {
  float        float_val;
  unsigned int uint_val;
  struct {
    #if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    unsigned int significand : 23;
    unsigned int biased_exponent : 8;
    unsigned int sign : 1;
    #elif __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    unsigned int sign : 1;
    unsigned int biased_exponent : 8;
    unsigned int significand : 23;
    #else
    #error "Unsupported byte order."
    #endif
  } parts;
} ieee754f32;


/* Function declarations: */
static void trim_string (char str []);
static char *bin_string (char str [], unsigned int const uint_val);
static bool parse_float (char const str [], float *f32);
static void print_float (FILE *const stream, float const f32);
static float reconstruct_float (ieee754f32 const f32);


/* Program entry point: */
int main (int argc, char const *argv [])
{ ieee754f32 f32;
  char given_value [152+1];

  /* Startup check to ensure bit field values are correct: */
  { ieee754f32 check;
    static_assert (sizeof(ieee754f32) == 4, "sizeof_ieee754f32_not_4");  /* sizeof(ieee754f32) == 4? */

    check.float_val = -1.5f;
    assert (check.parts.sign == 1);
    assert (check.parts.biased_exponent == 127);
    assert (check.parts.significand == 0x400000);
  }

  /* gather input */
  if (argc < (1+1))
  {
    fprintf (stdout, "Enter a value: ");
    if (fscanf (stdin, "%152s", given_value) != 1)
      strcpy (given_value, "invalid");
  }
  else
  {
    strncpy (given_value, argv [1], countof(given_value)-1);
    given_value [countof(given_value)-1] = '\0';
    fprintf (stdout, "Given value: %s\n", given_value);
  }

  /* try to parse it */
  trim_string (given_value);

  if (not parse_float (given_value, &f32.float_val))
  {
    fprintf (stderr, "\nNo valid value given, aborting.\n");
    return (EXIT_FAILURE);
  }

  /* IEEE 754 binary32 */
  { char str [32 + 1];

    /* output the full binary value */
    fprintf (stdout, "Representable value is "); print_float (stdout, f32.float_val); fputc ('\n', stdout);
    fprintf (stdout, "Integer value is %" PRIu32 "\n", f32.uint_val);
    fprintf (stdout, "Binary value is %s\n", bin_string (str, f32.uint_val));

    /* output parts separately */
    fprintf (stdout, "Sign bit is %" PRIu32 "\n", f32.parts.sign);             /* sign bit */
    fprintf (stdout, "Exponent is %" PRIu32 "\n", f32.parts.biased_exponent);  /* (biased) exponent */
    fprintf (stdout, "Significand is %" PRIu32 "\n", f32.parts.significand);   /* significand (i.e. the fraction or, slightly wrong, mantissa) */
  }

  /* try to reconstruct the original value */
  { ieee754f32 reconstructed;
    reconstructed.float_val = reconstruct_float (f32);

    fprintf (stdout, "Reconstructed value is ");
    print_float (stdout, reconstructed.float_val);
    fputc ('\n', stdout);

    if (strcasecmp (given_value, "M_PI") == 0)
      fprintf (stdout, "Correct value would be 3.1415926535897932384626\n");
    else
    if (strcasecmp (given_value, "M_E") == 0)
      fprintf (stdout, "Correct value would be 2.71828182845904523536\n");
  }

  return (EXIT_SUCCESS);
}


/* removes whitespace from both ends of the given string */
static void trim_string (char str [])
{
  ssize_t
    start, end,
    last;

  last = strlen (str);

  /* Left: */
  for (start = 0; start < last; ++start)
    if (!isspace (str [start]))
      break;

  /* Right: */
  for (end = last - 1; end >= start; --end)
    if (!isspace (str [end]))
      break;

  /* Move and Truncate: */
  if (end >= start)
  {
    if (start > 0)
      memmove (str, str + start, end - start + 1);
    str [end - start + 1] = '\0';
  }
  else
    str [0] = '\0';
}


/* create a 32-character string from a long int value */
static char *bin_string (char str [], unsigned int const uint_val)
{ unsigned int bit_mask = 0x80000000u;
  size_t i;

  for (i=0; i < 32; ++i)
  {
    str [i] = (uint_val & bit_mask)? '1' : '0';
    bit_mask >>= 1;
  }

  str [i] = '\0';

  return (str);
}


/* convert the string representation of a real number to an IEEE 754 binary32 */
static bool parse_float (char const str [], float *f32)
{ float value;
  int pos = 0;

  /* Try some “well-known” constants first: */
  if (strcasecmp (str, "M_PI") == 0)
    value = M_PI;
  else
  if (strcasecmp (str, "M_E") == 0)
    value = M_E;
  else
  {
    /* Try to convert to a binary32: */
    if (sscanf (str, " %f%n", &value, &pos) != 1)
      return (false);

    /* Reject in case of trailing characters: */
    if (str [pos] != '\0')
      return (false);
  }

  /* Store value in output argument: */
  if (f32)
   *f32 = value;

  return (true);
}


/* prints float values but strips trailing zeroes */
static void print_float (FILE * const stream, float const f32)
{ /* Smallest negative subnormal value: "-0." followed by a max. of 149 fractional digits
     Largest positive value that is not INFINITY: 340282346638528859811704183484516925440 */
  char float_str [152 + 1];

  snprintf (float_str, countof (float_str), "%.149f", f32);

  /* Remove trailing zeroes (if any) */
  { size_t index = strlen (float_str);

    while (index > 1)
      if (float_str [index-1] == '0' && float_str [index-2] != '.' && float_str [index-2] != ',')
        float_str [--index] = '\0';
      else
        break;
  }

  /* output resultant value */
  fprintf (stream, "%s", float_str);
}


/* Combine sign, exponent and significand to form a binary32 floating-point value */
#if defined(_MSC_VER) && _MSC_VER >= 1950  /* Visual Studio 2026 (or later)? */
#pragma warning (push)
#pragma warning (disable: 4756)  /* value = INFINITY;  // warning C4756: overflow in constant arithmetic */
#endif

static float reconstruct_float (ieee754f32 const f32)
{ ieee754f32 value;

  if (f32.parts.biased_exponent == 255)  /* Infinity <or> (Q)NaN/SNaN? */
  {
    if (f32.parts.significand == 0)
    {
      #if !defined(_MSC_VER) || _MSC_VER >= 1800  /* Visual Studio 2013 (or later)? */
      value.float_val = INFINITY;
      #else  /* No INFINITY macro, construct this value manually: */
      value.parts.sign = 0;
      value.parts.biased_exponent = 255;
      value.parts.significand = 0;
      #endif
    }
    else
    {
      #if !defined(_MSC_VER) || _MSC_VER >= 1800  /* Visual Studio 2013 (or later)? */
      value.float_val = NAN;
      #else  /* No NAN macro, construct this value manually: */
      value.parts.biased_exponent = 255;
      #endif
      value.parts.sign = f32.parts.sign;
      value.parts.significand = (1 << 23) - 1;  /* Note: a (quiet) NaN with a zero significand represents an “indefinite NaN”, otherwise a (regular) NaN */
      return (value.float_val);
    }
  }
  else if (f32.parts.biased_exponent == 0)  /* Zero <or> Subnormal? */
  {
    /* value = -1ˢ × (significand ÷ 2²³) × 2⁻¹²⁶ */
    value.float_val = ldexpf ((float)f32.parts.significand,
                              -23 - 126);
  }
  else /* normalized number */
  {
    /* value = -1ˢ × (1 + (significand ÷ 2²³)) × 2ᵇⁱᵃˢᵉᵈᵉˣᵖᵒⁿᵉⁿᵗ⁻¹²⁷ */
    value.float_val = ldexpf ((float)((1u << 23) | f32.parts.significand),
                              f32.parts.biased_exponent - 23 - 127);
  }

  return (f32.parts.sign? -value.float_val : value.float_val);
}

#if defined(_MSC_VER) && _MSC_VER >= 1950
#pragma warning (pop)
#endif
