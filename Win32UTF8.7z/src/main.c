#define WIN32_LEAN_AND_MEAN       /* Exclude APIs such as Cryptography, DDE, RPC, Shell, and Windows Sockets */
#define NOSERVICE                 /* Additional NOservice definitions: NOMCX, NOIME, NOSOUND, NOCOMM, NOKANJI, NORPC, ... */
#define _WINSOCKAPI_              /* Prevent windows.h from including winsock.h */
#define _WIN32_DCOM               /* Include all DCOM (Distributed Component Object Model) centric definitions */
#include <windows.h>              /* ... pull in Windows headers! */

#include <stdio.h>
#include <stdlib.h>               /* EXIT_SUCCESS, EXIT_FAILURE */
#include <locale.h>               /* setlocale() */
#include <iso646.h>               /* not, and, or, xor */


#include "OSVersion.c"

int main (void)
{
  #include "Win32UTF8.c"

  fprintf (stdout, "Microsoft Windows [Version %u.%u.%d]\n", winver.major_ver, winver.minor_ver, winver.build_num);
  fprintf (stdout, "\nVisual Studio 2022: _MSC_VER = %d, _MSC_FULL_VER = %d\n", _MSC_VER, _MSC_FULL_VER);

  /* Use UTF-8 code pages in Windows apps (taken from GitHub:cor3ntin/utf8-windows-demo):
     https://docs.microsoft.com/en-us/windows/apps/design/globalizing/use-utf8-code-page */
  #if (WDK_NTDDI_VERSION >= NTDDI_WIN10_19H1)
  fprintf (stdout, "\nTesting UTF-8 code page support:\n"
                   "--------------------------------\n");
  fprintf (stdout, "สวัสดีชาวโลก\n"
                   "今日は世界\n"
                   "مرحبا بالعالم 😊\n");
  fprintf (stdout, "--------------------------------\n");
  #endif

  return (EXIT_SUCCESS);
}
