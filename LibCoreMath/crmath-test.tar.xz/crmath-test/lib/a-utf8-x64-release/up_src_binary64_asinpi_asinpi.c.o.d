../lib/a-utf8-x64-release/up_src_binary64_asinpi_asinpi.c.o: \
 ../src/binary64/asinpi/asinpi.c
