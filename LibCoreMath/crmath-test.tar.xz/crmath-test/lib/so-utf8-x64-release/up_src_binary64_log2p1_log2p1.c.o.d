../lib/so-utf8-x64-release/up_src_binary64_log2p1_log2p1.c.o: \
 ../src/binary64/log2p1/log2p1.c ../src/binary64/log2p1/dint_log2p1.h
../src/binary64/log2p1/dint_log2p1.h:
