../lib/a-utf8-x86-release/up_src_binary32_exp10_exp10f.c.o: \
 ../src/binary32/exp10/exp10f.c
