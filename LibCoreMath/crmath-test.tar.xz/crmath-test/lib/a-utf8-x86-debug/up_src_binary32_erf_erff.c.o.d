../lib/a-utf8-x86-debug/up_src_binary32_erf_erff.c.o: \
 ../src/binary32/erf/erff.c
