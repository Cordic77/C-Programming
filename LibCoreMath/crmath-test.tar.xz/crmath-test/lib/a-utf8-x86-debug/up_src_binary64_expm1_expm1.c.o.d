../lib/a-utf8-x86-debug/up_src_binary64_expm1_expm1.c.o: \
 ../src/binary64/expm1/expm1.c
