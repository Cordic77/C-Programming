#pragma once
#ifndef SC_STATIC_ASSERT_H_
#define SC_STATIC_ASSERT_H_

#include "2011/static_assert.h"

#endif /* SC_STATIC_ASSERT_H_ */
